Audit reproduction bundle: draftjs-exporter

Use the web-sustainability-agents repository at implementation revision 23872e23cb5d477340190662cef1eb4619750552.
Canonical source: https://github.com/thibaudcolas/web-sustainability-agents
Install its locked Python/npm dependencies according to its contributing guide.

The session directory contains immutable collected observations, captured contextual text,
exact skill snapshots, reviews and scores. review-tasks contains the independent role
outputs, accepted handoffs and explicit coordinator resolutions. report-inputs contains
editorial wording and optional independently scoped enrichment/illustrations.

From the tool checkout, pass absolute paths to the extracted bundle:
uv run --locked --script audit/assess.py --reviews <bundle>/session/reviews.json --rubric <bundle>/session/rubric.json --weights <bundle>/session/impact-weights.json --assets <bundle>/session --output <bundle>/recomputed-scores.json
Compare recomputed-scores.json with session/scores.json before rendering.

Use audit/render_review.py with --session <bundle>/session,
--editorial <bundle>/report-inputs/editorial.json,
--energy <bundle>/session/energy/manifest.json and --output <bundle>/report.md.
Set --artifact-prefix session. Where present, also supply --annual and --traffic
from report-inputs and --screenshots report-inputs/screenshots/manifest.json with
--image-prefix report-inputs/screenshots. The published manifest records the exact
report-generation commands and input hashes using repository-relative paths.

Original collection and failed scoring receipts are preserved. The original scorer
rejected the nested energy manifest; score-receipt.json records a new calculation
campaign using the corrected path validator and identical judgments and evidence.
Do not rewrite the original receipt to suggest the corrected scorer collected data.

To repeat live collection, create a NEW session. Review its original plan and replace
contextEvidence paths with the matching context-inputs text records in this archive.
Keep original capture attribution if reusing those texts; refresh them explicitly for
new claims. Live results may differ. Failed navigation, security challenges and missing
worker traffic are not zero impact, and no collection recovery is claimed here.
