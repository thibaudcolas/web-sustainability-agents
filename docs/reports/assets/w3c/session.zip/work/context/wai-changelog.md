# Public document capture: wai-changelog

Publisher: World Wide Web Consortium (W3C)
Requested source: https://www.w3.org/WAI/fundamentals/changelog/
Final source: https://www.w3.org/WAI/fundamentals/changelog/
Captured at: 2026-11-06T08:44:48.222Z
HTTP status: 200
Capture method: headless Chromium, rendered main text; no performance measurement.
Limitations: publisher self-report; no independent verification, no internal records. Complete rendered main text within selected page, excluding navigation where main exists.

## Captured source wording

Changelog for Accessibility Fundamentals Overview
3 April 2025
In the “Research” section: updated the description of “Accessibility User Requirements”.
30 August 2023
In the “Research” section: updated the title and description of “Artificial Intelligence (AI) and Accessibility Research Symposium”.
3 August 2023
Updated the “Research” section.
16 June 2023
Added “Research” section for the following resources: “Artificial Intelligence and Accessibility” and “Accessibility User Requirements”.
4 March 2023
Trimmed the description of “Older Users and Web Accessibility”.
Added a link to Get Resources for ….
Combined descriptions of “How People with Disabilities Use the Web” and “Videos of How People with Disabilities Use the Web”.
Fix typos in “Video Introduction to Web Accessibility and W3C Standards”, “Web Accessibility Perspectives” and “How People with Disabilities Use the Web”.
4 January 2023
Updated the description of “Digital Accessibility Foundations — Free Online Course”.
Minor update in the description of “Course List of Digital Accessibility Education, Training, and Certification”.
29 December 2022
Expanded “Introduction to Web Accessibility” description: “Includes accessibility in context; why accessibility is important for individuals, businesses, society; making digital technology accessible; evaluating accessibility; and basic examples.”
Added a dedicated “Accessibility: It’s About People” section for the following resources: “Web Accessibility Perspectives”, “How People with Disabilities Use the Web”, “Older Users and Web Accessibility” and “Accessibility, Usability, and Inclusion”. Simplified the descriptions of those resources.
Simplified the description of “Essential Components of Web Accessibility”.
Added a dedicated “Digital Accessibility Courses” section for the following resources: “Digital Accessibility Foundations” and (new) “Course List”.
Added video icons in the following sections: “Video Introduction to Web Accessibility and W3C Standards”, “Web Accessibility Perspectives” and “How People with Disabilities Use the Web”
Added a banner at the bottom of the page.
13 May 2021
Added a link to the “Digital Accessibility Foundations — Free Online Course”.
 Help improve this page

Please share your ideas, suggestions, or comments via e-mail to the publicly-archived list wai@w3.org or via GitHub.

E-mail
Fork & Edit on GitHub
New GitHub Issue
 Back to Top

## Selected related public links

[]
