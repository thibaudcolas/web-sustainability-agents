# Public document capture: wcag-history

Publisher: World Wide Web Consortium (W3C)
Requested source: https://www.w3.org/standards/history/WCAG22/
Final source: https://www.w3.org/standards/history/WCAG22/
Captured at: 2026-11-06T08:44:47.825Z
HTTP status: 200
Capture method: headless Chromium, rendered main text; no performance measurement.
Limitations: publisher self-report; no independent verification, no internal records. Complete rendered main text within selected page, excluding navigation where main exists.

## Captured source wording

Web Content Accessibility Guidelines (WCAG) 2.2 publication history
Date	Status
12 December 2024	Recommendation
5 October 2023	Recommendation
20 July 2023	Proposed Recommendation
17 May 2023	Candidate Recommendation Draft
25 January 2023	Candidate Recommendation Draft
6 September 2022	Candidate Recommendation Snapshot
21 May 2021	Working Draft
13 May 2021	Working Draft
11 August 2020	Working Draft
27 February 2020	First Public Working Draft
In this section
WAI-WEBCONTENT history
WCAG20 history
WCAG21 history
wcag-3.0 history

## Selected related public links

[
  {
    "text": "WAI-WEBCONTENT history",
    "href": "https://www.w3.org/standards/history/WAI-WEBCONTENT/"
  },
  {
    "text": "WCAG20 history",
    "href": "https://www.w3.org/standards/history/WCAG20/"
  },
  {
    "text": "WCAG21 history",
    "href": "https://www.w3.org/standards/history/WCAG21/"
  },
  {
    "text": "wcag-3.0 history",
    "href": "https://www.w3.org/standards/history/wcag-3.0/"
  }
]
