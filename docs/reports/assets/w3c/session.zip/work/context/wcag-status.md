# Public document capture: wcag-status

Publisher: World Wide Web Consortium (W3C)
Requested source: https://www.w3.org/TR/WCAG22/
Final source: https://www.w3.org/TR/WCAG22/
Captured at: 2026-11-06T08:44:48.031Z
HTTP status: 200
Capture method: headless Chromium, rendered main text; no performance measurement.
Limitations: publisher self-report; no independent verification, no internal records. Excerpt truncated after 29,000 characters; omitted remainder and comments are not assessed.

## Captured source wording

↑
←

Web Content Accessibility Guidelines (WCAG) 2.2

W3C Recommendation 12 December 2024

More details about this document
This version:
https://www.w3.org/TR/2024/REC-WCAG22-20241212/
Latest published version:
https://www.w3.org/TR/WCAG22/
Latest editor's draft:
https://w3c.github.io/wcag/guidelines/22/
History:
https://www.w3.org/standards/history/WCAG22/
Commit history
Implementation report:
https://www.w3.org/WAI/WCAG22/implementation-report/
Previous Recommendation:
https://www.w3.org/TR/WCAG21/
Editors:
Alastair Campbell (Nomensa)
Chuck Adams (Oracle)
Rachael Bradley Montgomery (Library of Congress)
Michael Cooper (W3C)
Andrew Kirkpatrick (Adobe)
Feedback:
GitHub w3c/wcag (pull requests, new issue, open issues)
Errata:
Errata exists.

See also translations.

Copyright © 2020-2024 World Wide Web Consortium. W3C® liability, trademark and document use rules apply.

Abstract

Web Content Accessibility Guidelines (WCAG) 2.2 covers a wide range of recommendations for making web content more accessible. Following these guidelines will make content more accessible to a wider range of people with disabilities, including accommodations for blindness and low vision, deafness and hearing loss, limited movement, speech disabilities, photosensitivity, and combinations of these, and some accommodation for learning disabilities and cognitive limitations; but will not address every user need for people with these disabilities. These guidelines address accessibility of web content on any kind of device (including desktops, laptops, kiosks, and mobile devices). Following these guidelines will also often make web content more usable to users in general.

WCAG 2.2 success criteria are written as testable statements that are not technology-specific. Guidance about satisfying the success criteria in specific technologies, as well as general information about interpreting the success criteria, is provided in separate documents. See Web Content Accessibility Guidelines (WCAG) Overview for an introduction and links to WCAG technical and educational material.

WCAG 2.2 extends Web Content Accessibility Guidelines 2.1 [WCAG21], which was published as a W3C Recommendation June 2018. Content that conforms to WCAG 2.2 also conforms to WCAG 2.0 and WCAG 2.1. The WG intends that for policies requiring conformance to WCAG 2.0 or WCAG 2.1, WCAG 2.2 can provide an alternate means of conformance. The publication of WCAG 2.2 does not deprecate or supersede WCAG 2.0 or WCAG 2.1. While WCAG 2.0 and WCAG 2.1 remain W3C Recommendations, the W3C advises the use of WCAG 2.2 to maximize future applicability of accessibility efforts. The W3C also encourages use of the most current version of WCAG when developing or updating web accessibility policies.

Status of This Document

This section describes the status of this document at the time of its publication. A list of current W3C publications and the latest revision of this technical report can be found in the W3C technical reports index at https://www.w3.org/TR/.

To comment, file an issue in the W3C WCAG GitHub repository. Although the proposed success criteria in this document reference issues tracking discussion, the Working Group requests that public comments be filed as new issues, one issue per discrete comment. It is free to create a GitHub account to file issues. If filing issues in GitHub is not feasible, send email to public-agwg-comments@w3.org (comment archive).

This document was published by the Accessibility Guidelines Working Group as a Recommendation using the Recommendation track.

W3C recommends the wide deployment of this specification as a standard for the Web.

A W3C Recommendation is a specification that, after extensive consensus-building, is endorsed by W3C and its Members, and has commitments from Working Group members to royalty-free licensing for implementations.

This document was produced by a group operating under the W3C Patent Policy. W3C maintains a public list of any patent disclosures made in connection with the deliverables of the group; that page also includes instructions for disclosing a patent. An individual who has actual knowledge of a patent which the individual believes contains Essential Claim(s) must disclose the information in accordance with section 6 of the W3C Patent Policy.

This document is governed by the 03 November 2023 W3C Process Document.

table of contents
Abstract
Status of This Document
Introduction
Background on WCAG 2
WCAG 2 Layers of Guidance
WCAG 2.2 Supporting Documents
Requirements for WCAG 2.2
Comparison with WCAG 2.1
New Features in WCAG 2.2
Numbering in WCAG 2.2
Conformance to WCAG 2.2
Later Versions of Accessibility Guidelines
1.
Perceivable
1.1
Text Alternatives
1.1.1
Non-text Content
1.2
Time-based Media
1.2.1
Audio-only and Video-only (Prerecorded)
1.2.2
Captions (Prerecorded)
1.2.3
Audio Description or Media Alternative (Prerecorded)
1.2.4
Captions (Live)
1.2.5
Audio Description (Prerecorded)
1.2.6
Sign Language (Prerecorded)
1.2.7
Extended Audio Description (Prerecorded)
1.2.8
Media Alternative (Prerecorded)
1.2.9
Audio-only (Live)
1.3
Adaptable
1.3.1
Info and Relationships
1.3.2
Meaningful Sequence
1.3.3
Sensory Characteristics
1.3.4
Orientation
1.3.5
Identify Input Purpose
1.3.6
Identify Purpose
1.4
Distinguishable
1.4.1
Use of Color
1.4.2
Audio Control
1.4.3
Contrast (Minimum)
1.4.4
Resize Text
1.4.5
Images of Text
1.4.6
Contrast (Enhanced)
1.4.7
Low or No Background Audio
1.4.8
Visual Presentation
1.4.9
Images of Text (No Exception)
1.4.10
Reflow
1.4.11
Non-text Contrast
1.4.12
Text Spacing
1.4.13
Content on Hover or Focus
2.
Operable
2.1
Keyboard Accessible
2.1.1
Keyboard
2.1.2
No Keyboard Trap
2.1.3
Keyboard (No Exception)
2.1.4
Character Key Shortcuts
2.2
Enough Time
2.2.1
Timing Adjustable
2.2.2
Pause, Stop, Hide
2.2.3
No Timing
2.2.4
Interruptions
2.2.5
Re-authenticating
2.2.6
Timeouts
2.3
Seizures and Physical Reactions
2.3.1
Three Flashes or Below Threshold
2.3.2
Three Flashes
2.3.3
Animation from Interactions
2.4
Navigable
2.4.1
Bypass Blocks
2.4.2
Page Titled
2.4.3
Focus Order
2.4.4
Link Purpose (In Context)
2.4.5
Multiple Ways
2.4.6
Headings and Labels
2.4.7
Focus Visible
2.4.8
Location
2.4.9
Link Purpose (Link Only)
2.4.10
Section Headings
2.4.11
Focus Not Obscured (Minimum)
2.4.12
Focus Not Obscured (Enhanced)
2.4.13
Focus Appearance
2.5
Input Modalities
2.5.1
Pointer Gestures
2.5.2
Pointer Cancellation
2.5.3
Label in Name
2.5.4
Motion Actuation
2.5.5
Target Size (Enhanced)
2.5.6
Concurrent Input Mechanisms
2.5.7
Dragging Movements
2.5.8
Target Size (Minimum)
3.
Understandable
3.1
Readable
3.1.1
Language of Page
3.1.2
Language of Parts
3.1.3
Unusual Words
3.1.4
Abbreviations
3.1.5
Reading Level
3.1.6
Pronunciation
3.2
Predictable
3.2.1
On Focus
3.2.2
On Input
3.2.3
Consistent Navigation
3.2.4
Consistent Identification
3.2.5
Change on Request
3.2.6
Consistent Help
3.3
Input Assistance
3.3.1
Error Identification
3.3.2
Labels or Instructions
3.3.3
Error Suggestion
3.3.4
Error Prevention (Legal, Financial, Data)
3.3.5
Help
3.3.6
Error Prevention (All)
3.3.7
Redundant Entry
3.3.8
Accessible Authentication (Minimum)
3.3.9
Accessible Authentication (Enhanced)
4.
Robust
4.1
Compatible
4.1.1
Parsing (Obsolete and removed)
4.1.2
Name, Role, Value
4.1.3
Status Messages
5.
Conformance
5.1
Interpreting Normative Requirements
5.2
Conformance Requirements
5.2.1
Conformance Level
5.2.2
Full pages
5.2.3
Complete processes
5.2.4
Only Accessibility-Supported Ways of Using Technologies
5.2.5
Non-Interference
5.3
Conformance Claims (Optional)
5.3.1
Required Components of a Conformance Claim
5.3.2
Optional Components of a Conformance Claim
5.4
Statement of Partial Conformance - Third Party Content
5.5
Statement of Partial Conformance - Language
5.6
Privacy Considerations
5.7
Security Considerations
6.
Glossary
7.
Input Purposes for User Interface Components
A.
Change Log
B.
Acknowledgments
B.1
Participants of the AG WG active in the development of this document:
B.2
Other previously active WCAG WG participants and other contributors to WCAG 2.0, WCAG 2.1, or supporting resources
B.3
Enabling funders
C.
References
C.1
Informative references
Introduction

This section is non-normative.

Background on WCAG 2

Web Content Accessibility Guidelines (WCAG) 2.2 defines how to make web content more accessible to people with disabilities. Accessibility involves a wide range of disabilities, including visual, auditory, physical, speech, cognitive, language, learning, and neurological disabilities. Although these guidelines cover a wide range of issues, they are not able to address the needs of people with all types, degrees, and combinations of disability. These guidelines also make web content more usable by older individuals with changing abilities due to aging and often improve usability for users in general.

WCAG 2.2 is developed through the W3C process in cooperation with individuals and organizations around the world, with a goal of providing a shared standard for web content accessibility that meets the needs of individuals, organizations, and governments internationally. WCAG 2.2 builds on WCAG 2.0 [WCAG20] and WCAG 2.1 [WCAG21], which in turn built on WCAG 1.0 [WAI-WEBCONTENT] and is designed to apply broadly to different web technologies now and in the future, and to be testable with a combination of automated testing and human evaluation. For an introduction to WCAG, see the Web Content Accessibility Guidelines (WCAG) Overview.

Significant challenges were encountered in defining additional criteria to address cognitive, language, and learning disabilities, including a short timeline for development as well as challenges in reaching consensus on testability, implementability, and international considerations of proposals. Work will carry on in this area in future versions of WCAG. We encourage authors to refer to our supplemental guidance on improving inclusion for people with disabilities, including learning and cognitive disabilities, people with low-vision, and more.

Web accessibility depends not only on accessible content but also on accessible web browsers and other user agents. Authoring tools also have an important role in web accessibility. For an overview of how these components of web development and interaction work together, see:

Essential Components of Web Accessibility
User Agent Accessibility Guidelines (UAAG) Overview
Authoring Tool Accessibility Guidelines (ATAG) Overview

Where this document refers to WCAG 2 it is intended to mean any and all versions of WCAG that start with 2.

WCAG 2 Layers of Guidance

The individuals and organizations that use WCAG vary widely and include web designers and developers, policy makers, purchasing agents, teachers, and students. In order to meet the varying needs of this audience, several layers of guidance are provided including overall principles, general guidelines, testable success criteria and a rich collection of sufficient techniques, advisory techniques, and documented common failures with examples, resource links and code.

Principles - At the top are four principles that provide the foundation for web accessibility: perceivable, operable, understandable, and robust. See also Understanding the Four Principles of Accessibility.

Guidelines - Under the principles are guidelines. The 13 guidelines provide the basic goals that authors should work toward in order to make content more accessible to users with different disabilities. The guidelines are not testable, but provide the framework and overall objectives to help authors understand the success criteria and better implement the techniques.

Success Criteria - For each guideline, testable success criteria are provided to allow WCAG 2.2 to be used where requirements and conformance testing are necessary such as in design specification, purchasing, regulation, and contractual agreements. In order to meet the needs of different groups and different situations, three levels of conformance are defined: A (lowest), AA, and AAA (highest). Additional information on WCAG levels can be found in Understanding Levels of Conformance.

Sufficient and Advisory Techniques - For each of the guidelines and success criteria in the WCAG 2.2 document itself, the working group has also documented a wide variety of techniques. The techniques are informative and fall into two categories: those that are sufficient for meeting the success criteria and those that are advisory. The advisory techniques go beyond what is required by the individual success criteria and allow authors to better address the guidelines. Some advisory techniques address accessibility barriers that are not covered by the testable success criteria. Where common failures are known, these are also documented. See also Sufficient and Advisory Techniques in Understanding WCAG 2.2.

All of these layers of guidance (principles, guidelines, success criteria, and sufficient and advisory techniques) work together to provide guidance on how to make content more accessible. Authors are encouraged to view and apply all layers that they are able to, including the advisory techniques, in order to best address the needs of the widest possible range of users.

Note that even content that conforms at the highest level (AAA) will not be accessible to individuals with all types, degrees, or combinations of disability, particularly in the cognitive, language, and learning areas. Authors are encouraged to consider the full range of techniques, including the advisory techniques, Making Content Usable for People with Cognitive and Learning Disabilities, as well as to seek relevant advice about current best practice to ensure that web content is accessible, as far as possible, to this community. Metadata may assist users in finding content most suitable for their needs.

WCAG 2.2 Supporting Documents

The WCAG 2.2 document is designed to meet the needs of those who need a stable, referenceable technical standard. Other documents, called supporting documents, are based on the WCAG 2.2 document and address other important purposes, including the ability to be updated to describe how WCAG would be applied with new technologies. Supporting documents include:

How to Meet WCAG 2.2 - A customizable quick reference to WCAG 2.2 that includes all of the guidelines, success criteria, and techniques for authors to use as they are developing and evaluating web content. This includes content from WCAG 2.0, 2.1, and 2.2, and can be filtered in many ways to help authors focus on relevant content.

Understanding WCAG 2.2 - A guide to understanding and implementing WCAG 2.2. There is a short "Understanding" document for each guideline and success criterion in WCAG 2.2 as well as key topics.

Techniques for WCAG 2.2 - A collection of techniques and common failures, each in a separate document that includes a description, examples, code and tests.

The WCAG 2 Documents - A brief introduction to the WCAG 2 supporting documents and supplemental guidance.

What's New in WCAG 2.2 introduces the new success criteria with persona quotes that illustrate the accessibility issues.

See Web Content Accessibility Guidelines (WCAG) Overview for a description of the WCAG 2.2 supporting material, including education resources related to WCAG 2. Additional resources covering topics such as the business case for web accessibility, planning implementation to improve the accessibility of websites, and accessibility policies are listed in WAI Resources.

Requirements for WCAG 2.2

WCAG 2.2 meets a set of requirements for WCAG 2.2 which, in turn, inherit requirements from previous WCAG 2 versions. Requirements structure the overall framework of guidelines and ensure backwards compatibility. The Working Group also used a less formal set of acceptance criteria for success criteria, to help ensure success criteria are similar in style and quality to those in WCAG 2.0. These requirements constrained what could be included in WCAG 2.2. This constraint was important to preserve its nature as a dot-release of WCAG 2.

Comparison with WCAG 2.1

WCAG 2.2 was initiated with the goal to continue the work of WCAG 2.1: Improving accessibility guidance for three major groups: users with cognitive or learning disabilities, users with low vision, and users with disabilities on mobile devices. Many ways to meet these needs were proposed and evaluated, and a set of these were refined by the Working Group. Structural requirements inherited from WCAG 2.0, clarity and impact of proposals, and timeline led to the final set of success criteria included in this version. The Working Group considers that WCAG 2.2 incrementally advances web content accessibility guidance for all these areas, but underscores that not all user needs are met by these guidelines.

WCAG 2.2 builds on and is backwards compatible with WCAG 2.1, meaning web pages that conform to WCAG 2.2 are at least as accessible as pages that conform to WCAG 2.1. Requirements have been added that build on 2.1 and 2.0. WCAG 2.2 has removed one success criterion, 4.1.1 Parsing. Authors that are required by policy to conform with WCAG 2.0 or 2.1 will be able to update content to WCAG 2.2, but may need to continue to test and report 4.1.1. Authors following more than one version of the guidelines should be aware of the following additions.

New Features in WCAG 2.2

WCAG 2.2 extends WCAG 2.1 by adding new success criteria, definitions to support them, and guidelines to organize the additions. This additive approach helps to make it clear that sites which conform to WCAG 2.2 also conform to WCAG 2.1. The Accessibility Guidelines Working Group recommends that sites adopt WCAG 2.2 as their new conformance target, even if formal obligations mention previous versions, to provide improved accessibility and to anticipate future policy changes.

The following success criteria are new in WCAG 2.2:

2.4.11 Focus Not Obscured (Minimum) (AA)
2.4.12 Focus Not Obscured (Enhanced) (AAA)
2.4.13 Focus Appearance (AAA)
2.5.7 Dragging Movements (AA)
2.5.8 Target Size (Minimum) (AA)
3.2.6 Consistent Help (A)
3.3.7 Redundant Entry (A)
3.3.8 Accessible Authentication (Minimum) (AA)
3.3.9 Accessible Authentication (Enhanced) (AAA)

The new success criteria may reference new terms that have also been added to the glossary and form part of the normative requirements of the success criteria.

WCAG 2.2 also introduces new sections detailing aspects of the specification which may impact privacy and security.

Numbering in WCAG 2.2

In order to avoid confusion for implementers for whom backwards compatibility to WCAG 2 versions is important, new success criteria in WCAG 2.2 have been appended to the end of the set of success criteria within their guideline. This avoids the need to change the section number of success criteria from WCAG 2, which would be caused by inserting new success criteria between existing success criteria in the guideline, but it means success criteria in each guideline are no longer grouped by conformance level. The order of success criteria within each guideline does not imply information about conformance level; only the conformance level indicator (A / AA / AAA) on the success criterion itself indicates this. The WCAG 2.2 Quick Reference will provide a way to view success criteria grouped by conformance level, along with many other filter and sort options.

Conformance to WCAG 2.2

WCAG 2.2 uses the same conformance model as WCAG 2.0. It is intended that sites that conform to WCAG 2.2 also conform to WCAG 2.0 and WCAG 2.1, which means they meet the requirements of any policies that reference WCAG 2.0 or WCAG 2.1, while also better meeting the needs of users on the current Web.

Later Versions of Accessibility Guidelines

In parallel with WCAG 2.2, the Accessibility Guidelines Working Group is developing another major version of accessibility guidelines. The result of this work is expected to be a more substantial restructuring of web accessibility guidance than would be realistic for dot-releases of WCAG 2. The work follows a research-focused, user-centered design methodology to produce the most effective and flexible outcome, including the roles of content authoring, user agent support, and authoring tool support. This is a multi-year effort, so WCAG 2.2 is needed as an interim measure to provide updated web accessibility guidance to reflect changes on the web since the publication of WCAG 2.0. The Working Group might also develop additional interim versions, continuing with WCAG 2.2, on a similar short timeline to provide additional support while the major version is completed.

1. Perceivable

Information and user interface components must be presentable to users in ways they can perceive.

Guideline 1.1 Text Alternatives
Understanding Text Alternatives
|


How to Meet Text Alternatives

Provide text alternatives for any non-text content so that it can be changed into other forms people need, such as large print, braille, speech, symbols or simpler language.

Success Criterion 1.1.1 Non-text Content
Understanding Non-text Content
|


How to Meet Non-text Content

(Level A)

All non-text content that is presented to the user has a text alternative that serves the equivalent purpose, except for the situations listed below.

Controls, Input

If non-text content is a control or accepts user input, then it has a name that describes its purpose. (Refer to Success Criterion 4.1.2 for additional requirements for controls and content that accepts user input.)

Time-Based Media

If non-text content is time-based media, then text alternatives at least provide descriptive identification of the non-text content. (Refer to Guideline 1.2 for additional requirements for media.)

Test

If non-text content is a test or exercise that would be invalid if presented in text, then text alternatives at least provide descriptive identification of the non-text content.

Sensory

If non-text content is primarily intended to create a specific sensory experience, then text alternatives at least provide descriptive identification of the non-text content.

CAPTCHA

If the purpose of non-text content is to confirm that content is being accessed by a person rather than a computer, then text alternatives that identify and describe the purpose of the non-text content are provided, and alternative forms of CAPTCHA using output modes for different types of sensory perception are provided to accommodate different disabilities.

Decoration, Formatting, Invisible

If non-text content is pure decoration, is used only for visual formatting, or is not presented to users, then it is implemented in a way that it can be ignored by assistive technology.

Guideline 1.2 Time-based Media
Understanding Time-based Media
|


How to Meet Time-based Media

Provide alternatives for time-based media.

Success Criterion 1.2.1 Audio-only and Video-only (Prerecorded)
Understanding Audio-only and Video-only (Prerecorded)
|


How to Meet Audio-only and Video-only (Prerecorded)

(Level A)

For prerecorded audio-only and prerecorded video-only media, the following are true, except when the audio or video is a media alternative for text and is clearly labeled as such:

Prerecorded Audio-only

An alternative for time-based media is provided that presents equivalent information for prerecorded audio-only content.

Prerecorded Video-only

Either an alternative for time-based media or an audio track is provided that presents equivalent information for prerecorded video-only content.

Success Criterion 1.2.2 Captions (Prerecorded)
Understanding Captions (Prerecorded)
|


How to Meet Captions (Prerecorded)

(Level A)

Captions are provided for all prerecorded audio content in synchronized media, except when the media is a media alternative for text and is clearly labeled as such.

Success Criterion 1.2.3 Audio Description or Media Alternative (Prerecorded)
Understanding Audio Description or Media Alternative (Prerecorded)
|


How to Meet Audio Description or Media Alternative (Prerecorded)

(Level A)

An alternative for time-based media or audio description of the prerecorded video content is provided for synchronized media, except when the media is a media alternative for text and is clearly labeled as such.

Success Criterion 1.2.4 Captions (Live)
Understanding Captions (Live)
|


How to Meet Captions (Live)

(Level AA)

Captions are provided for all live audio content in synchronized media.

Success Criterion 1.2.5 Audio Description (Prerecorded)
Understanding Audio Description (Prerecorded)
|


How to Meet Audio Description (Prerecorded)

(Level AA)

Audio description is provided for all prerecorded video content in synchronized media.

Success Criterion 1.2.6 Sign Language (Prerecorded)
Understanding Sign Language (Prerecorded)
|


How to Meet Sign Language (Prerecorded)

(Level AAA)

Sign language interpretation is provided for all prerecorded audio content in synchronized media.

Success Criterion 1.2.7 Extended Audio Description (Prerecorded)
Understanding Extended Audio Description (Prerecorded)
|


How to Meet Extended Audio Description (Prerecorded)

(Level AAA)

Where pauses in foreground audio are insufficient to allow audio descriptions to convey the sense of the video, extended audio description is provided for all prerecorded video content in synchronized media.

Success Criterion 1.2.8 Media Alternative (Prerecorded)
Understanding Media Alternative (Prerecorded)
|


How to Meet Media Alternative (Prerecorded)

(Level AAA)

An alternative for time-based media is provided for all prerecorded synchronized media and for all prerecorded video-only media.

Success Criterion 1.2.9 Audio-only (Live)
Understanding Audio-only (Live)
|


How to Meet Audio-only (Live)

(Level AAA)

An alternative for time-based media that presents equivalent information for live audio-only content is provided.

Guideline 1.3 Adaptable
Understanding Adaptable
|


How to Meet Adaptable

Create content that can be presented in different ways (for example simpler layout) without losing information or structure.

Success Criterion 1.3.1 Info and Relationships
Understanding Info and Relationships
|


How to Meet Info and Relationships

(Level A)

Information, structure, and relationships conveyed through presentation can be programmatically determined or are available in text.

Success Criterion 1.3.2 Meaningful Sequence
Understanding Meaningful Sequence
|


How to Meet Meaningful Sequence

(Level A)

When the sequence in which content is presented affects its meaning, a correct reading sequence can be programmatically determined.

Success Criterion 1.3.3 Sensory Characteristics
Understanding Sensory Characteristics
|


How to Meet Sensory Characteristics

(Level A)

Instructions provided for understanding and operating content do not rely solely on sensory characteristics of components such as shape, color, size, visual location, orientation, or sound.

NOTE

For requirements related to color, refer to Guideline 1.4.

Success Criterion 1.3.4 Orientation
Understanding Orientation
|


How to Meet Orientation

(Level AA)

Content does not restrict its view and operation to a single display orientation, such as portrait or landscape, unless a specific display orientation is essential.

NOTE

Examples where a particular display orientation may be essential are a bank check, a piano application, slides for a projector or television, or virtual reality content where content is not necessarily restricted to landscape or portrait display orientation.

Success Criterion 1.3.5 Identify Input Purpose
Understanding Identify Input Purpose
|


How to Meet Identify Input Purpose

(Level AA)

The purpose of each input field collecting information about the user can be programmatically determined when:

The input field serves a purpose identified in the Input Purposes for user interface components section; and
The content is implemented using technologies with support for identifying the expected meaning for form input data.
Success Criterion 1.3.6 Identify Purpose
Understanding Identify Purpose
|


How to Meet Identify Purpose

(Level AAA)

In content implemented using markup languages, the purpose of user interface components, icons, and regions can be programmatically determined.

Guideline 1.4 Distinguishable
Understanding Distinguishable
|


How to Meet Distinguishable

Make it easier for users to see and hear content including separating foreground from background.

Success Criterion 1.4.1 Use of Color
Understanding Use of Color
|


How to Meet Use of Color

(Level A)

Color is not used as the only visual means of conveying information, indicating an action, prompting a response, or distinguishing a visual element.

NOTE

This success criterion addresses color perception specifically. Other forms of perception are covered in Guideline 1.3 including programmatic access to color and other visual presentation coding.

Success C

## Selected related public links

[]
