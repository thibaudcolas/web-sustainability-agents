# Public document capture: sustainability-mission

Publisher: World Wide Web Consortium (W3C)
Requested source: https://www.w3.org/mission/sustainability/
Final source: https://www.w3.org/mission/sustainability/
Captured at: 2026-11-06T08:44:47.715Z
HTTP status: 200
Capture method: headless Chromium, rendered main text; no performance measurement.
Limitations: publisher self-report; no independent verification, no internal records. Complete rendered main text within selected page, excluding navigation where main exists.

## Captured source wording

Web Sustainability
Read this page in:
中文（简体）
Page contents
How W3C approaches sustainability
Developing sustainability work
Web Sustainability Guidelines (WSG)
WSG Impact Ratings
Sponsoring
Shape a sustainable web as a W3C Member

For technology to be developed sustainably, it must integrate economic growth, social well-being and environmental protection. Creating a sustainable web that protects people, the planet, and prosperity is a part of creating a web that works — for everyone. The web was designed for people, but its technology has ramifications for the environment and wider society.

Users are concerned about the impact technology is having on the ecosystem, whether that’s the impact of e-waste, or increased demand on power generation and consumption, or data centers, or the emissions of digital products and services. Organizations also need resilience more than ever. We are discussing ways in which the design, development, and operation of digital products and services can reduce negative impacts on the environment while ensuring that the platform remains a good place for people.

We work with individuals, designers and developers, software and hardware vendors and regulators to actively engage with our work and to do their part to make the web more sustainable: a web which is open to all, conserves environmental resources, and supports people and society.

How W3C approaches sustainability §
anchor
Develop web sustainability guidelines
Measure the sustainability impact of implementations
Create resources to assist creators with web sustainability
Coordinate with research and development that may impact the future sustainability of the web
Support education and outreach on web sustainability
Coordinate with horizontal review groups to assess sustainability impact of specifications

Tzviya Siegman, Director of Sustainability at W3C talks about what digital sustainability is and provides an overview of the Web Sustainability Guidelines.

Developing sustainability work §
anchor
Sustainable Web Interest Group

The mission of the Sustainable Web Interest Group is to improve digital sustainability so that the web works better for all people and the planet.

A big focus of the group is to develop W3C Web Sustainability Guidelines and their companion Impact Ratings. A complete list of the interest group’s deliverables can be found on its GitHub readme.

 

Web Sustainability Guidelines (WSG) §
anchor

W3C Web Sustainability Guidelines are about building digital products that are better for people, planet, and prosperity. In practice, that means using less data, energy, processing, and hardware; keeping websites simple, fast, accessible, and inclusive; reducing waste and unnecessary third-party services; and making sustainability part of product and business decisions.

WSG Impact Ratings §
anchor

W3C Web Sustainability Guidelines Impact Ratings help teams understand which sustainability improvements have the biggest impact across people, planet, and prosperity, and how difficult or time-consuming they may be to implement. Each guideline is rated by its potential impact and an estimated implementation time frame, helping organizations prioritize where to focus their efforts. In short: it helps teams understand the potential impact of each recommendation and prioritize what to tackle first.

Sponsoring §
anchor

Organizations can become a Web for All Champion; an option that is open to W3C Members as well as non-members.

Sponsor this work

Shape a sustainable web as a W3C Member §
anchor

W3C Members play a significant role in shaping the Web.

Contact W3C to learn more about the benefits of W3C Membership to play a significant role yourself!

In this section
Accessibility
Internationalization
Privacy
Web Security
Web Sustainability

## Selected related public links

[]
