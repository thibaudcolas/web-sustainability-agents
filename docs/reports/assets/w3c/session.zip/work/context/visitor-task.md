# Anonymous desktop task observation

{
  "startUrl": "https://www.w3.org/",
  "capturedAt": "2026-11-06T08:44:49.127Z",
  "viewport": {
    "width": 1365,
    "height": 900
  },
  "audience": "Anonymous English desktop reader using a pointer and text input; no account, personal data or submission",
  "steps": [
    {
      "type": "click",
      "selector": "main a[href=\"https://www.w3.org/standards/\"]:text-is(\"standards and guidelines\")",
      "before": "https://www.w3.org/",
      "after": "https://www.w3.org/standards/"
    },
    {
      "type": "click",
      "selector": "main a[href=\"/TR/\"]",
      "before": "https://www.w3.org/standards/",
      "after": "https://www.w3.org/TR/"
    },
    {
      "type": "fill",
      "selector": "input[name=\"filter-tr-name\"]",
      "value": "WCAG"
    },
    {
      "type": "click",
      "selector": "button:has-text(\"Show results\")",
      "before": "https://www.w3.org/TR/",
      "after": "https://www.w3.org/TR/?filter-tr-name=WCAG"
    },
    {
      "type": "click",
      "selector": "a[href=\"https://www.w3.org/TR/WCAG22/\"]",
      "before": "https://www.w3.org/TR/?filter-tr-name=WCAG",
      "after": "https://www.w3.org/TR/WCAG22/"
    }
  ],
  "success": {
    "url": "https://www.w3.org/TR/WCAG22/",
    "selector": "h1",
    "text": "Web Content Accessibility Guidelines (WCAG) 2.2"
  },
  "actualUrl": "https://www.w3.org/TR/WCAG22/",
  "selectorMatches": 1,
  "visible": true,
  "actualText": "Web Content Accessibility Guidelines (WCAG) 2.2",
  "limitations": "Agent walkthrough only; keyboard-only, mobile, impaired-network, geographic and representative user testing were not performed.",
  "allPostconditionsMatch": true
}

No cookie banner or accept/reject controls were observed on the seven sampled pages during fresh-context exploratory navigation and visible-control inspection. This is a bounded observation, not proof of absent tracking or consent obligations.
