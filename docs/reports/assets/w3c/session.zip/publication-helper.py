#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.14,<3.15"
# dependencies = []
# [tool.uv]
# required-version = ">=0.12.20,<0.13"
# ///
"""Publish the reviewed five-site campaign, preserving frozen capture identities."""
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '.audit-work/diversity'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')

def execute(argv):
    result = subprocess.run(argv, cwd=ROOT, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr + result.stdout)
    return {'argv': argv, 'exitCode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}

CLI = ['uv', 'run', '--locked', '--script', 'audit/cli.py', 'tool']
IMPLEMENTATION = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
for name in sys.argv[1:]:
    work = BASE / name
    session = work / 'session'
    public = ROOT / 'docs/reports/assets' / name
    public.mkdir(parents=True, exist_ok=True)
    packet = read(session / 'packet.json')
    for rel, digest in {**packet['frozenFiles'], **packet['sourceSHA256']}.items():
        assert sha(session / rel) == digest, rel
    for path in session.glob('*.json'):
        shutil.copyfile(path, public / path.name)
    shutil.copytree(session / 'energy', public / 'energy', dirs_exist_ok=True)
    shutil.copytree(work / 'review-tasks', public / 'review-tasks', dirs_exist_ok=True)
    shutil.copyfile(work / 'review-tasks/reconciliation.accepted.json', public / 'review-handoffs.json')
    for rel in ['editorial.json', 'annual.json', 'claims-supplement.json', 'setup-handoff.json', 'coordinator-commands.json']:
        shutil.copyfile(work / rel, public / rel)
    if (work / 'publication-qa.json').exists():
        shutil.copyfile(work / 'publication-qa.json', public / 'publication-qa.json')
    shutil.copyfile(work / 'report-receipt.json', public / 'editorial-receipt.json')
    shutil.copyfile(BASE / 'traffic.json', public / 'traffic.json')
    supplements = public / 'supplements'
    shutil.copytree(work / 'energy', supplements, dirs_exist_ok=True)
    shutil.copyfile(work / 'energy/manifest.json', supplements / 'energy.json')
    for rel in ['energy-plan.json', 'energy-command.json', 'energy-interventions.json']:
        if (work / rel).exists():
            shutil.copyfile(work / rel, supplements / rel)
    presentation = {'schemaVersion': 'report-presentation-v1', 'site': packet['site'], 'reviewSHA256': sha(session / 'review.json'), 'reason': 'Report reproduction metadata and separately collected energy/annual supplements; no outcome or priority overrides.'}
    write(supplements / 'presentation.json', presentation)
    prefix = f'assets/{name}'
    asset = f'docs/reports/{prefix}'
    report = ROOT / f'docs/reports/{name}.md'
    command = CLI + ['render_review', '--session', asset, '--artifact-prefix', prefix, '--editorial', asset + '/editorial.json', '--presentation', asset + '/supplements/presentation.json', '--energy', asset + '/supplements/energy.json', '--annual', asset + '/annual.json', '--traffic', asset + '/traffic.json', '--supplement-prefix', prefix + '/supplements', '--output', str(report.relative_to(ROOT))]
    if (work / 'screenshots/manifest.json').exists():
        shutil.copytree(work / 'screenshots', public / 'screenshots', dirs_exist_ok=True)
        command += ['--screenshots', asset + '/screenshots/manifest.json', '--image-prefix', prefix + '/screenshots']
    render_receipt = execute(command)
    execute(['npx', 'prettier', '--write', str(report.relative_to(ROOT))])
    render_receipt.update({'schemaVersion': 'report-reproduction-v1', 'inputSHA256': {rel: sha(public / rel) for rel in ['review.json', 'reviews.json', 'scores.json', 'editorial.json', 'annual.json', 'traffic.json', 'supplements/energy.json', 'supplements/presentation.json']}, 'rendererSHA256': sha(ROOT / 'audit/render_review.py'), 'outputSHA256': sha(report)})
    write(supplements / 'report-receipt.json', render_receipt)
    export = work / 'chart-export'
    chart_command = CLI + ['report', '--input', asset + '/staged.json', '--output', str(export.relative_to(ROOT)), '--energy', asset + '/supplements/energy.json', '--traffic', asset + '/traffic.json', '--assessments', asset + '/scores.json', '--annual', asset + '/annual.json']
    execute(chart_command)
    for suffix in ['json', 'csv']:
        candidates = list(export.glob('*.' + suffix))
        assert len(candidates) == 1
        shutil.copyfile(candidates[0], public / ('chart-data.' + suffix))
    execute(CLI + ['assess', '--reviews', asset + '/reviews.json', '--rubric', asset + '/rubric.json', '--weights', asset + '/impact-weights.json', '--assets', asset, '--output', str((work / 'recalculated.json').relative_to(ROOT))])
    assert read(work / 'recalculated.json')['scores'] == read(public / 'scores.json')['scores']
    reproduction = ('These are public, anonymous observations without source checkouts or form submissions.\n'
                    'session/ preserves the original frozen evidence, skills, reviews and scoring inputs.\n'
                    'work/ preserves setup context, tasks, failed review attempts, explicit resolutions and separate energy/annual enrichment.\n'
                    'publication/ preserves the report inputs and reproduction receipt.\n'
                    'The collection revision is recorded in session/receipt.json.\n'
                    f'Use implementation revision {IMPLEMENTATION} for report rendering; it also reproduces the same scores.\n'
                    'The publication render command is in publication/supplements/report-receipt.json. Run from the repository root.\n'
                    'Recalculation of saved evidence is reproducible; fresh browsing or model judgments can differ.\n'
                    'GreenFrame is a resource-counter energy model, separately sampled with an older browser. W3C failures are unavailable.\n'
                    'Absolute original paths are provenance, not dependencies for reading this archive.\n')
    with zipfile.ZipFile(public / 'session.zip', 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(session.rglob('*')):
            if path.is_file():
                z.write(path, 'session/' + str(path.relative_to(session)))
        for path in sorted(work.rglob('*')):
            if path.is_file() and not path.is_relative_to(session) and not path.is_relative_to(export) and path.suffix not in {'.pyc', '.headers'} and path.name not in {'preview.md', 'report.md', 'recalculated.json'}:
                z.write(path, 'work/' + str(path.relative_to(work)))
        for path in sorted(public.rglob('*')):
            if path.is_file() and path.name not in {'session.zip', 'manifest.json'}:
                z.write(path, 'publication/' + str(path.relative_to(public)))
        z.write(BASE / 'traffic.json', 'work/traffic.json')
        z.write(Path(__file__), 'publication-helper.py')
        z.write(Path(__file__).with_suffix('.py.lock'), 'publication-helper.py.lock')
        z.writestr('REPRODUCE.txt', reproduction)
    with zipfile.ZipFile(public / 'session.zip') as z:
        for rel, digest in {**packet['frozenFiles'], **packet['sourceSHA256']}.items():
            assert hashlib.sha256(z.read('session/' + rel)).hexdigest() == digest, rel
    manifest = {'schemaVersion': 'audit-publication-v1', 'site': packet['site'], 'collectionRevision': read(session / 'receipt.json')['gitRevision'], 'executionMode': 'native-subagents', 'publicationReview': 'Anonymous public observations and contextual records; no source checkout, authenticated task or form submission. Partial and failed captures and superseded review attempts retained.', 'commands': {'report': command, 'chartData': chart_command}, 'publicationFilesSHA256': {str(p.relative_to(public)): sha(p) for p in sorted(public.rglob('*')) if p.is_file() and p != public / 'manifest.json'}, 'reportSHA256': sha(report), 'reproduction': reproduction}
    manifest['implementationRevision'] = IMPLEMENTATION
    write(public / 'manifest.json', manifest)
    for rel, digest in manifest['publicationFilesSHA256'].items():
        assert sha(public / rel) == digest, rel
    print(name + ': published; frozen hashes, archive and recalculated scores verified', flush=True)
