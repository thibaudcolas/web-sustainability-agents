import asyncio,json
from pathlib import Path
from datetime import datetime,UTC
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True)
  for site in ['nhs','tate']:
   c=await b.new_context(viewport={'width':1440,'height':1000});page=await c.new_page(); steps=[]
   origin='https://www.'+('nhs.uk' if site=='nhs' else 'tate.org.uk')
   try:
    await page.goto(origin+'/',wait_until='domcontentloaded');await page.wait_for_timeout(1000)
    if site=='nhs':
     selectors=['#nhsuk-cookie-banner__link_accept','header a[href="/live-well/"]','main a[href="https://www.nhs.uk/live-well/exercise/"]','main a[href="https://www.nhs.uk/live-well/exercise/walking-for-health/"]']
    else:
     selectors=['a[href="/visit/tate-modern"]:has-text("Free admission")','a[href="#accessibility"]']
    for selector in selectors:
     loc=page.locator(selector);count=await loc.count();print(site,selector,count,flush=True)
     await loc.click(timeout=7000);await page.wait_for_timeout(800)
     steps.append({'selector':selector,'count':count,'urlAfter':page.url,'heading':await page.locator('h1').all_text_contents()})
    d={'capturedAt':datetime.now(UTC).isoformat(),'url':page.url,'steps':steps,'h1':await page.locator('h1').all_text_contents(),'body':(await page.locator('body').inner_text())[:25000],'buttons':await page.locator('button').evaluate_all('(xs)=>xs.map(x=>({id:x.id,text:x.innerText}))'),'inputs':await page.locator('input').evaluate_all('(xs)=>xs.map(x=>({name:x.name,type:x.type,required:x.required,id:x.id,placeholder:x.placeholder}))')}
    if site=='tate':d['accessibilityVisible']=await page.locator('#accessibility').is_visible()
    Path(f'.audit-work/diversity/{site}/captures/journey.json').write_text(json.dumps(d,indent=2));print(site,'SUCCESS',page.url,flush=True)
   except Exception as e:
    Path(f'.audit-work/diversity/{site}/captures/journey-error.json').write_text(json.dumps({'error':str(e),'steps':steps,'url':page.url}));print(site,'ERROR',str(e),flush=True)
   await c.close()
  # Verify acceptance separately; discard only anonymous test-context preference.
  c=await b.new_context();page=await c.new_page();await page.goto('https://www.nhs.uk/',wait_until='domcontentloaded');await page.wait_for_timeout(1000)
  await page.locator('#nhsuk-cookie-banner__link_accept_analytics').click();await page.wait_for_timeout(500)
  Path('.audit-work/diversity/nhs/captures/accept-control.json').write_text(json.dumps({'capturedAt':datetime.now(UTC).isoformat(),'url':page.url,'body':(await page.locator('body').inner_text())[:1000]},indent=2))
  print('nhs acceptance verified',flush=True);await c.close();await b.close()
asyncio.run(main())
