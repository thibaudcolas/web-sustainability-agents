# walking-task

Source: https://www.nhs.uk/
Captured at: 2026-11-06T08:43:27.977707+00:00
Scope: Anonymous English readers using a desktop browser with pointer input and JavaScript, 1440 by 1000 CSS pixels: start at https://www.nhs.uk/, reject analytics cookies, follow Healthy living > Exercise > Walking for health, and reach the article heading and full reading content. No account, symptom input, booking or submitted health data. Keyboard-only, assistive-technology and constrained-device completion are outside this assessment scope.
Limitations: Agent pointer walkthrough; not representative-user research, keyboard-only test or full accessibility audit.

Actual anonymous Chromium desktop actions and states:
{
  "capturedAt": "2026-11-06T08:43:27.977707+00:00",
  "url": "https://www.nhs.uk/live-well/exercise/walking-for-health/",
  "steps": [
    {
      "selector": "#nhsuk-cookie-banner__link_accept",
      "count": 1,
      "urlAfter": "https://www.nhs.uk/",
      "heading": [
        "\n              NHS website for England\n              \n                Find information and services to help you manage your health\n              \n            "
      ]
    },
    {
      "selector": "header a[href=\"/live-well/\"]",
      "count": 1,
      "urlAfter": "https://www.nhs.uk/live-well/",
      "heading": [
        "Healthy living"
      ]
    },
    {
      "selector": "main a[href=\"https://www.nhs.uk/live-well/exercise/\"]",
      "count": 1,
      "urlAfter": "https://www.nhs.uk/live-well/exercise/",
      "heading": [
        "\n   Exercise \n"
      ]
    },
    {
      "selector": "main a[href=\"https://www.nhs.uk/live-well/exercise/walking-for-health/\"]",
      "count": 1,
      "urlAfter": "https://www.nhs.uk/live-well/exercise/walking-for-health/",
      "heading": [
        "\n   Walking for health \n"
      ]
    }
  ],
  "h1": [
    "\n   Walking for health \n"
  ],
  "body": "Skip to main content\nSearch the NHS website\nSearch\nMy account\nHealth A to Z\nNHS services\nHealthy living\nMental health\nCare and support\nHome\nHealthy living\nExercise\nWalking for health\n\nWalking is simple, free and one of the easiest ways to get more active, lose weight and become healthier.\n\nSometimes overlooked as a form of exercise, walking briskly can help you build stamina, burn excess calories and\u00a0make your heart\u00a0healthier.\n\nYou do not have to walk for hours. A brisk 10-minute\u00a0daily\u00a0walk has lots of health benefits and counts towards your\u00a0150 minutes of weekly exercise, as recommended in the physical activity guidelines for adults aged 19 to 64.\n\nBefore you start\n\nAny shoes or trainers that are comfortable, provide adequate support and do not cause blisters will do.\n\nIf you're walking to work,\u00a0you could wear your usual work clothes with a comfy pair of shoes and change shoes when you get into work.\n\nFor long walks, you may want to take some water, healthy snacks, a spare top, sunscreen and a sun hat in a small backpack.\n\nIf you start\u00a0going for\u00a0longer walks regularly, you may want to invest in a waterproof jacket and some specialist walking shoes for more challenging routes.\n\nHow do I know if I'm walking fast enough?\n\nA brisk walk is about\u00a03 miles an hour, which is faster than a stroll.\n\nYou can tell you're walking briskly if you can still talk but cannot sing the words to a song.\n\nYou could also try using the free Active 10 app on your smartphone.\n\nIt tells you when you're walking fast enough and suggests ways to fit in some more brisk walking.\n\nDownload Active 10 from the NHS Better Health website\n\nWhat if I'm not very active?\n\nIf you're not very active but are able to walk, increase your walking distance gradually.\n\nIf your joints are a problem, check whether your local swimming pool holds exercise classes.\n\nThe water helps to support your joints while you move and can help you strengthen your muscles.\n\nIf you cannot leave the house, why not see if one of our free Fitness Studio exercise videos can help.\n\nStaying motivated\nMake it a habit\n\nThe easiest way to walk more is to make walking a habit.\n\nThink of ways to include walking in your daily routine.\n\nExamples include:\u00a0\n\nwalking part of your journey to work\nwalking to the shops\nusing the stairs instead of the lift\nleaving the car behind for short journeys\nwalking the kids to school\ndoing a regular walk with a friend\ngoing for a stroll with family or friends after dinner\nListen to music\n\nWalking while listening to\u00a0music or a podcast can take your mind off the effort.\n\nIt\u00a0can\u00a0also get you into a rhythm and help you walk faster.\n\nYou'll be surprised\u00a0at how fast the time goes when you're walking to your favourite tunes.\n\nUse the\u00a0Active 10 app\n\nActive 10\u00a0allows you to track\u00a0how\u00a0much and how fast\u00a0you have walked.\u00a0\n\nTo keep things interesting, it gives you goals to work towards and rewards your progress.\n\nDownload Active 10 from the NHS Better Health website\n\nMix it up\n\nAdd variety to your walks. You do not have to travel to the countryside to find a rewarding walk.\n\nTowns and cities offer interesting walks, including parks, heritage trails, canal towpaths, riverside paths, commons, woodlands, heaths and nature reserves.\n\nJoin a walking group\n\nWalking in a group is a great way to start walking, make new friends and stay motivated.\n\nRamblers organises group walks\u00a0for health, leisure and as a means of getting around\u00a0for people of all ages, backgrounds and levels of fitness.\n\nFor details of many locally organised walks in towns and cities, as well as the countryside, visit the Ramblers website.\n\nMore in Exercise\nWhy exercise is important\nBenefits of exercise\nWhy we should sit less\nExercise guidelines\nPhysical activity guidelines for adults aged 19 to 64\nPhysical activity guidelines for older adults\nPhysical activity guidelines for children and young people\nPhysical activity guidelines for children (under 5 years)\nFitness advice for wheelchair users\nStrength and flexibility exercises\nHow to improve your strength and flexibility\nStrength and Flex exercise plan: How-to videos\nBalance exercises\nSitting exercises\nStrength exercises\nFlexibility exercises\nExercises for sciatica problems\nRunning and aerobic exercises\nHow to warm up before exercising\nHow to stretch after exercising\nKnee exercises for runners\nKnee pain and other running injuries\nWalking for health\nFitness studio exercise videos\nAbout our Fitness studio videos\nAerobic exercise videos\nStrength and resistance exercise videos\nPilates and yoga exercise videos\n\nPage last reviewed: 15 December 2022\nNext review due: 15 December 2025\n\nSupport links\nHome\nHealth A to Z\nNHS services\nHealthy living\nMental health\nCare and support\nNHS App\nView your test results\nAbout the NHS\nHealthcare abroad\nManage NHS profiles\nOther NHS websites\nAbout us\nReport an issue with the NHS website\nAccessibility statement\nOur policies\nCookies\n\n\u00a9 Crown copyright",
  "buttons": [
    {
      "id": "",
      "text": "Search"
    },
    {
      "id": "toggle-menu",
      "text": "\n              Browse\n              More\n            "
    }
  ],
  "inputs": [
    {
      "name": "q",
      "type": "text",
      "required": false,
      "id": "search-field",
      "placeholder": "Search"
    }
  ]
}
