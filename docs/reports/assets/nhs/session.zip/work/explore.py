import asyncio,json
from pathlib import Path
from datetime import datetime,UTC
from playwright.async_api import async_playwright
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True)
  for site,url in [('tate','https://www.tate.org.uk/'),('nhs','https://www.nhs.uk/')]:
   c=await b.new_context(viewport={'width':1440,'height':1000})
   pg=await c.new_page()
   try:
    r=await pg.goto(url,wait_until='domcontentloaded',timeout=35000)
    await pg.wait_for_timeout(3500)
    d={'capturedAt':datetime.now(UTC).isoformat(),'url':pg.url,'status':r.status if r else None,'title':await pg.title(),'buttons':await pg.locator('button').evaluate_all('(xs)=>xs.map(x=>({text:x.innerText,id:x.id,aria:x.getAttribute("aria-label")}))'),'links':await pg.locator('a[href]').evaluate_all('(xs)=>xs.map(x=>({text:x.innerText,href:x.getAttribute("href")}))'),'body':(await pg.locator('body').inner_text())[:18000]}
    Path(f'.audit-work/diversity/{site}/captures/browser-home.json').write_text(json.dumps(d,indent=2))
    print(site,json.dumps({k:v for k,v in d.items() if k not in ['links','body']}))
   except Exception as e: print(site,type(e).__name__,str(e))
   await c.close()
  await b.close()
asyncio.run(main())
