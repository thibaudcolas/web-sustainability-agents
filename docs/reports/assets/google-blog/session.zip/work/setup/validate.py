import asyncio
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from audit.workflow import validate_plan
from audit.probes import validate_plan as validate_probes
from playwright.async_api import async_playwright
root=Path('.audit-work/diversity/google-blog')
plan=json.loads((root/'plan.json').read_text())
validate_plan(plan)
validate_probes(plan)
async def main():
 results={'capturedAt':datetime.now(timezone.utc).isoformat(),'workflowValidation':'passed','probeValidation':'passed','pages':[]}
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(headless=True)
  for target in plan['pages']:
   context=await browser.new_context(viewport={'width':1440,'height':1000},locale='en-GB')
   page=await context.new_page()
   response=await page.goto(target['url'],wait_until='domcontentloaded')
   button=page.locator('.glue-cookie-notification-bar__accept')
   await button.wait_for(state='visible')
   item={'id':target['id'],'status':response.status,'finalUrl':page.url,'acknowledgmentCount':await button.count(),'buttonText':await button.inner_text()}
   await button.click()
   item['acknowledgmentHiddenAfterClick']=not await button.is_visible()
   results['pages'].append(item)
   await context.close()
  context=await browser.new_context(viewport={'width':1440,'height':1000},locale='en-GB')
  page=await context.new_page()
  journey=plan['journeys'][0]
  await page.goto(journey['url'],wait_until='domcontentloaded')
  for action in journey['actions']:
   await page.locator(action['selector']).click()
  await page.wait_for_url(journey['success']['url'])
  h=page.locator(journey['success']['selector'])
  results['journey']={'id':journey['id'],'urlMatch':page.url==journey['success']['url'],'selectorCount':await h.count(),'textMatch':journey['success']['text'] in await h.inner_text(),'mainContainsStegra':'Stegra' in await page.locator('main').inner_text()}
  await browser.close()
 (root/'setup/validation.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results,indent=2))
asyncio.run(main())
