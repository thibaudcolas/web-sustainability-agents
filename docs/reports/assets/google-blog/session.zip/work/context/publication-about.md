Source: https://blog.google/about/
Captured at: 2026-11-06T08:46:36.403865+00:00
Kind: public-document
Scope: About News from Google, publication purpose, authorship, follow and contact information.
Limitations: Publisher self-description; no CMS review schedule or publication footprint verified.

Skip to main content
Innovation & AI
Products & platforms
Company news
Feed
Newsletter
About News from Google

Follow Us

Share
On this page
About us
Authors
Follow us
Newsletter
Contact us

News from Google is Google's official publication for the latest company announcements, updates, and behind-the-scenes storytelling. Our contributors include hundreds of the world’s leading engineers, product managers, and internet pioneers who work directly on products and services like Google Search, Ads, Gemini, Maps, Android, Chrome, Pixel, and Play.

News from Google also regularly features opinions and perspectives from Google’s senior leadership, including CEO Sundar Pichai, Google DeepMind co-founder and Chair Demis Hassabis, and President of Global Affairs Kent Walker.

News from Google has published thousands of articles covering topics ranging from our work in generative AI with Google DeepMind to the latest Google Cloud innovations. News from Google is also the central hub for breaking news and announcements from annual events like Google I/O and Made by Google.

News from Google is designed to grow and change as Google does, so as we introduce new products and technologies they will have a home on this blog. And alongside the biggest news of the day, we’ll also share quick product tips and ideas to make your life easier.

In short: If there’s anything you want to know about what’s happening at Google right now, News from Google is where you should start.

Noteworthy authors

Googlers from across the company contribute to News from Google — ranging from engineers and designers to doctors and scientists. Here are a few examples:

Sundar Pichai

Sundar is the CEO of Alphabet and Google and serves on Alphabet’s Board of Directors. Under his leadership, Google has been focused on developing products and services, powered by the latest advances in AI, that offer help in moments big and small.

Demis Hassabis

Demis Hassabis is the co-founder and Chair of Google DeepMind, one of the world’s leading AI research groups. DeepMind has produced landmark research breakthroughs such as AlphaGo, the first program to beat the world champion at the game of Go, and AlphaFold, which was heralded as a solution to the 50-year grand challenge of protein folding.

James Manyika

James is a senior vice president at Google. He focuses on technology and society, including areas ranging from AI to the future of work and the digital economy, computing infrastructure, sustainability, and other areas that have the potential for broad impact on society. Prior to Google, he spent over 25 years at McKinsey & Company, including serving on its board, and is now senior partner emeritus and chair emeritus of the McKinsey Global Institute (MGI).

Ruth Porat

As President and Chief Investment Officer, Ruth is responsible for the company’s corporate investments and investment vehicles, including GV and CapG, the Other Bets investment portfolio, Real Estate and Workplace Services, and other company infrastructure. She was previously SVP and CFO of Alphabet and Google.

Kent Walker

Kent is the President of Global Affairs at Google and Alphabet, where he works at the intersection of technology, policy, and legal issues. He joined Google in 2006, and currently oversees the company’s engagement with governments around the world, content policies, and philanthropic efforts.

Rick Osterloh

Rick Osterloh leads Platforms & Devices, a group of products and services that bring the best of Google’s innovation in AI, software, and hardware to users, partners, and developers. This includes the overall Android platform, Google Play, Chrome browser, ChromeOS, Google One, Google Photos, the Pixel portfolio, Nest, Fitbit, and more. He works closely with partners across the ecosystem, and oversees multiple Google products that serve more than a billion users each.

How to follow us

You can also find the latest news and stories from Google on our official social channels — including Instagram, YouTube, LinkedIn, X, and TikTok — and our weekly email newsletter.

Get the latest news from Google in your inbox

Sign up for our newsletters with product updates, event information, special offers, and more.

Subscribe

Your information will be used in accordance with Google's privacy policy. You may opt out at any time.

Contact us

Need assistance or want to report a problem with a Google product or service? Here’s the best place to start.

If you are a member of the press, contact press@google.com.

Google Headquarters

1600 Amphitheatre Parkway

Mountain View, CA 94043

650-253-0000

Privacy
Terms
Help
More of Google
Google Products
About the Blog
Global (English)
Africa (English)
Australia (English)
Brasil (Português)
Canada (English)
Canada (Français)
Česko (Čeština)
Deutschland (Deutsch)
España (Español)
France (Français)
Greece (Ελληνικά)
India (English)
Indonesia (Bahasa Indonesia)
Ireland (English)
Italia (Italiano)
日本 (日本語)
대한민국 (한국어)
Latinoamérica (Español)
Malaysia (English)
الشرق الأوسط وشمال أفريقيا (اللغة العربية)
MENA (English)
Nederlands (Nederland)
New Zealand (English)
Polska (Polski)
Portugal (Português)
România (Română)
Sverige (Svenska)
ประเทศไทย (ไทย)
Türkiye (Türkçe)
台灣 (中文)
