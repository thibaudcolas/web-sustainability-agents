Source: https://blog.google/company-news/outreach-and-initiatives/sustainability/google-stegra-green-steel/
Captured at: 2026-11-06T08:46:36.403865+00:00
Kind: public-document
Scope: September 17, 2026 corporate infrastructure announcement published on the audited blog.
Limitations: Google self-report about industrial materials and data-center construction; not evidence of blog-specific sustainability performance or editorial review execution.

Skip to main content
Innovation & AI
Products & platforms
Company news
Feed
Newsletter
Home
Company News
Outreach & Initiatives
Sustainability
Helping bring the world’s first large-scale, near-zero emissions steel plant online

Sep 17, 2026

1 min read

Google is partnering with Stegra to help bring their large-scale, green hydrogen-based, near-zero emissions steel plant online.

Ben Townsend

Head of Infrastructure & Sustainability

Jenna Stauffer

Head of Strategic Priorities, Climate Operations

Share
1:09
Listen to article
1:59 minutes
Read AI-generated summary

We’re partnering with Stegra to help bring the world’s first large-scale, green hydrogen-based, near-zero emissions steel plant online. The steel is designed to meet the International Energy Agency’s (IEA) definition for near-zero emissions steel production, marking an important step toward addressing the impact of the hard-to-decarbonize steel industry.

While traditional steel manufacturing relies on coal to process iron, Stegra’s plant in Boden, Sweden, will use renewable electricity to generate green hydrogen. The hydrogen is then reacted with iron ore to produce iron. Stegra estimates that removing coal from the process can cut emissions by up to 95% compared to traditional blast furnace manufacturing.

Under the new agreement, Google will receive environmental attribute certificates (EACs) from a portion (up to 91,000 metric tons) of the steel produced in Stegra’s first year of production. Companies purchase EACs to drive demand for sustainably produced materials, address construction emissions, and help scale and finance these early stage technologies.

By supporting innovative technologies and partnering with coalitions like the Sustainable Steel Buyers Platform, we hope to bring more green building materials to market and increasingly incorporate them into our own operations. We estimate this can reduce the embodied carbon emissions from data center infrastructure by up to 40%. In 2025, we successfully integrated low-carbon concrete, steel, or a combination of both in over 20 construction projects.

Posted in:
Sustainability
Global Network
Related stories
Global Network
Investing in Wyoming’s infrastructure, energy and workforce
By Steve Walter
Sustainability
Colorado students joined a Google hackathon to tackle energy grid challenges.
By John Tribbia
Sustainability
Powering sub-Saharan Africa beyond the grid
By Irwin Boutboul & Yasha Wallin
Global Network
We are working with Voltus to build a 1-gigawatt virtual power plant.
Global Network
Partnering to strengthen the grid and support local communities in Arkansas
By News from Google Team
Sustainability
We’re supporting nature restoration through sustainable farming in Brazil.
By Randy Spock
Get the latest news from Google in your inbox

Sign up for our newsletters with product updates, event information, special offers, and more.

Subscribe

Your information will be used in accordance with Google's privacy policy. You may opt out at any time.

Privacy
Terms
Help
More of Google
Google Products
About the Blog
Global (English)
Africa (English)
Australia (English)
Brasil (Português)
Canada (English)
Canada (Français)
Česko (Čeština)
Deutschland (Deutsch)
España (Español)
France (Français)
Greece (Ελληνικά)
India (English)
Indonesia (Bahasa Indonesia)
Ireland (English)
Italia (Italiano)
日本 (日本語)
대한민국 (한국어)
Latinoamérica (Español)
Malaysia (English)
الشرق الأوسط وشمال أفريقيا (اللغة العربية)
MENA (English)
Nederlands (Nederland)
New Zealand (English)
Polska (Polski)
Portugal (Português)
România (Română)
Sverige (Svenska)
ประเทศไทย (ไทย)
Türkiye (Türkçe)
台灣 (中文)
