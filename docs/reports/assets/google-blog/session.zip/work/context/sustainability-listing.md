Source: https://blog.google/company-news/outreach-and-initiatives/sustainability/
Captured at: 2026-11-06T08:46:36.403865+00:00
Kind: public-document
Scope: Current English sustainability collection topic page.
Limitations: Sampled listing only; corporate initiatives do not establish audited publication goals.

blog.google uses cookies from Google to deliver and enhance the quality of its services and to analyze traffic. Learn more

OK, got it
Skip to main content
Innovation & AI
Products & platforms
Company news
Feed
Newsletter
Home
Company News
Outreach & Initiatives
Sustainability

News about our work to build a more sustainable future through our products, operations and partnerships.

Follow Us

Sustainability
Helping bring the world’s first large-scale, near-zero emissions steel plant online

Google is partnering with Stegra to help bring their first-of-its-kind, near-zero emissions steel plant online.

By Ben Townsend
Head of Infrastructure & Sustainability
Read article
All the Latest
Showing 6 articles.
Sustainability
Global Network
Colorado students joined a Google hackathon to tackle energy grid challenges.
By John Tribbia
Senior Staff Data Scientist
Sustainability
Google in Africa
Powering sub-Saharan Africa beyond the grid
By Irwin Boutboul
Startups for Sustainable Development Lead
Sustainability
Google in Latin America
We’re supporting nature restoration through sustainable farming in Brazil.
By Randy Spock
Head of Carbon Removal
Pixel
Sustainability
Making your Pixel devices last longer through design, repair, and reuse
By Steven Nickel
Director of Operations
Sustainability
Why we're backing America's existing nuclear plants
By Amanda Peterson Corio
Global Head of Data Center Energy
Sustainability
Google Cloud
Google in Latin America
Google is supporting water resilience in Chile.
By Ben Townsend
Head of Infrastructure & Sustainability
Explore more articles
Privacy
Terms
Help
More of Google
Google Products
About the Blog
Global (English)
Africa (English)
Australia (English)
Brasil (Português)
Canada (English)
Canada (Français)
Česko (Čeština)
Deutschland (Deutsch)
España (Español)
France (Français)
Greece (Ελληνικά)
India (English)
Indonesia (Bahasa Indonesia)
Ireland (English)
Italia (Italiano)
日本 (日本語)
대한민국 (한국어)
Latinoamérica (Español)
Malaysia (English)
الشرق الأوسط وشمال أفريقيا (اللغة العربية)
MENA (English)
Nederlands (Nederland)
New Zealand (English)
Polska (Polski)
Portugal (Português)
România (Română)
Sverige (Svenska)
ประเทศไทย (ไทย)
Türkiye (Türkçe)
台灣 (中文)
