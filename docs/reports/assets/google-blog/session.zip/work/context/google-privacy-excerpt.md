Source: https://policies.google.com/privacy
Captured at: 2026-11-06T08:46:36.403865+00:00
Kind: public-document
Scope: First 10,000 characters of the rendered Google Privacy Policy, including effective date and provided email purpose example.
Limitations: Explicit excerpt of a broad corporate policy; not evidence of blog-specific retention or actual downstream processing. Remaining policy text omitted.

Skip to main content
Privacy & Terms
Sign in
Overview
Privacy Policy
Terms of Service
Technologies
FAQ
Introduction
Information Google collects
Why Google collects data
Your privacy controls
Sharing your information
Keeping your information secure
Exporting & deleting your information
Retaining your information
Compliance & cooperation with regulators
European requirements
About this policy
Related privacy practices
Data transfer frameworks
Key terms
Partners
Updates
GOOGLE PRIVACY POLICY

When you use our services, you’re trusting us with your information. We understand this is a big responsibility and work hard to protect your information and put you in control.

This Privacy Policy is meant to help you understand what information we collect, why we collect it, and how you can update, manage, export, and delete your information.

If European Union or United Kingdom data protection law applies to the processing of your information, you can review the European requirements section below to learn more about your rights and Google’s compliance with these laws.

Privacy Checkup

Looking to change your privacy settings?

Take the Privacy Checkup

Effective October 16, 2026 | Archived versions | Download PDF

We build a range of services that help millions of people daily to explore and interact with the world in new ways. Our services include:

Google apps, sites, and devices, like Search, YouTube, and Google Home
Platforms like the Chrome browser and Android operating system
Products that are integrated into third-party apps and sites, like ads, analytics, and embedded Google Maps

You can use our services in a variety of ways to manage your privacy. For example, you can sign up for a Google Account if you want to create and manage content like emails and photos, or see more relevant search results. And you can use many Google services when you’re signed out or without creating an account at all, like searching on Google or watching YouTube videos. You can also choose to browse the web in a private mode, like Chrome Incognito mode, which helps keep your browsing private from other people who use your device. And across our services, you can adjust your privacy settings to control whether we collect some types of data and how we use it.

To help explain things as clearly as possible, we’ve added examples, explanatory videos, and definitions for key terms. And if you have any questions about this Privacy Policy, you can contact us.

INFORMATION GOOGLE COLLECTS
We want you to understand the types of information we collect as you use our services

We collect information to provide better services to all our users — from figuring out basic stuff like which language you speak, to more complex things like which ads you’ll find most useful, the people who matter most to you online, or which YouTube videos you might like. The information Google collects, and how that information is used, depends on how you use our services and how you manage your privacy controls.

Google also collects and uses data that is not associated with your account. For example, when you’re not signed in to a Google Account, we store the information we collect with unique identifiers tied to the browser, application, or device you’re using. This allows us to do things like maintain your preferences across browsing sessions, such as your preferred language or whether to show you more relevant search results or ads based on your activity across devices.

When you’re signed in, we also collect information that we store with your Google Account, which we treat as personal information.

Things you create or provide to us

When you create a Google Account, you provide us with personal information that includes your name and a password. You can also choose to add a phone number or payment information to your account. Even if you aren’t signed in to a Google Account, you might choose to provide us with information — like an email address to communicate with Google or receive updates about our services.

We also collect the content you create, upload, or receive from others when using our services. This includes things like email you write and receive, photos and videos you save, docs and spreadsheets you create, and comments you make on YouTube videos.

Information we collect as you use our services
Your apps, browsers & devices

We collect information about the apps, browsers, and devices you use to access Google services, which helps us provide features like automatic product updates and dimming your screen if your battery runs low.

The information we collect includes unique identifiers, browser type and settings, device type and settings, operating system, mobile network information including carrier name and phone number, and application version number. We also collect information about the interaction of your apps, browsers, and devices with our services, including IP address, crash reports, system activity, and the date, time, and referrer URL of your request.

We collect this information when a Google service on your device contacts our servers — for example, when you install an app from the Play Store or when a service checks for automatic updates. If you’re using an Android device with Google apps, your device periodically contacts Google servers to provide information about your device and connection to our services. This information includes things like your device type and carrier name, crash reports, which apps you've installed, and, depending on your device settings, other information about how you’re using your Android device.

Your activity

We collect information about your activity in our services, which we use to do things like recommend a YouTube video you might like. The activity information we collect may include:

Terms you search for
Videos you watch
Views and interactions with content and ads
Voice and audio information
Purchase activity
People with whom you communicate or share content
Activity on third-party sites and apps that use our services
Chrome browsing history you’ve synced with your Google Account

If you use our services to make and receive calls or send and receive messages, we may collect call and message log information like your phone number, calling-party number, receiving-party number, forwarding numbers, sender and recipient email address, time and date of calls and messages, duration of calls, routing information, and types and volumes of calls and messages.

You can visit your Google Account to find and manage activity information that’s saved by your activity controls.

Go to Google Account

Your location information

We collect location information when you use our services, which helps us offer features like driving directions, search results for things near you, and ads based on your location.

Depending on the products you’re using and settings you choose, Google may use different types of location information to help make some services and products you use more helpful. These include:

GPS and other sensor data from your device
IP address
Activity on Google services, such as from your searches or places you label like home or work
Information about things near your device, such as Wi-Fi access points, cell towers, and Bluetooth-enabled devices

The types of location data we collect and how long we store it depend in part on your device and account settings. For example, you can turn your Android device’s location on or off using the device’s settings app. You can also turn on Timeline if you want to create a private map of where you go with your signed-in devices. And if your Web & App Activity setting is enabled, your searches and other activity from Google services, which may also include location information, is saved to your Google Account. Learn more about how we use location information.

In some circumstances, Google also collects information about you from publicly accessible sources. For example, if your name appears in your local newspaper, Google’s Search engine may index that article and display it to other people if they search for your name. We may also collect information about you from trusted partners, such as directory services who provide us with business information to be displayed on Google’s services, marketing partners who provide us with information about potential customers of our business services, and security partners who provide us with information to protect against abuse. We also receive information from partners to provide advertising and research services on their behalf.

We use various technologies to collect and store information, including cookies, pixel tags, local storage, such as browser web storage or application data caches, databases, and server logs.

WHY GOOGLE COLLECTS DATA
We use data to build better services

We use the information we collect from all our services for the following purposes:

Provide our services

We use your information to deliver our services, like processing the terms you search for in order to return results or helping you share content by suggesting recipients from your contacts.

Maintain & improve our services

We also use your information to ensure our services are working as intended, such as tracking outages or troubleshooting issues that you report to us. And we use your information to make improvements to our services — for example, understanding which search terms are most frequently misspelled helps us improve spell-check features used across our services.

Develop new services

We use the information we collect in existing services to help us develop new ones. For example, understanding how people organized their photos in Picasa, Google’s first photos app, helped us design and launch Google Photos.

Provide personalized services, including content and ads

We use the information we collect to customize our services for you, including providing recommendations, personalized content, and customized search results. For exampl
