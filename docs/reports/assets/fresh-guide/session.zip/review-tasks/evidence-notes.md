# Fresh guide quantitative evidence notes

This note summarizes the frozen fresh guide packet only; no scores or guideline outcomes are assigned. All kB/MB are decimal (1 kB = 1,000 bytes).

| Page | Initial bytes | Initial kB | Requests | Image kB | Image share | SWDM g CO₂e | Provisional rating |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| home | 59,103 | 59.103 | 5 | 0.000 | 0.0% | 0.008759 | A+ |
| overview | 63,630 | 63.630 | 7 | 9.600 | 15.1% | 0.009430 | A+ |
| manage-images | 233,091 | 233.091 | 10 | 177.373 | 76.1% | 0.034544 | A+ |
| search | 50,608 | 50.608 | 5 | 0.000 | 0.0% | 0.007500 | A+ |
| release-notes | 354,332 | 354.332 | 12 | 297.681 | 84.0% | 0.052512 | A |
| about | 54,159 | 54.159 | 6 | 0.000 | 0.0% | 0.008026 | A+ |

Each independent cold anonymous load uses 1280 × 800 CSS px, DPR 1, a three-second observation and main CDP received bytes including overhead. All six are complete within that protocol; no unresolved requests, resource errors or coverage gaps occur. Both later cumulative checkpoints add 0 bytes/requests. No consent action occurs: no_banner is a no-action branch. Do not add the phase totals or call the difference cookie savings.

Manage images: four eager screenshots total 177.373 kB, at y=878.4/1582.2/2451.6/3245.4px. Sizes are 49.263/51.253/39.075/37.782 kB. The lower three total 128.110 kB. Release notes: six eager images total 297.681 kB, at y=1024.8/1864.8/2751.3/3688.5/4364.6/5049.2px. Sizes are 75.141/49.221/54.004/23.787/40.439/55.089 kB; lower five total 222.540 kB. Overview's single image is only 9.600 kB. These identify initial traffic for deferral tests, not measured avoidable savings. Native lazy-loading thresholds can fetch near-fold images.

All eleven external images are negotiated WebP despite .png URLs. Screenshots render at 756px desktop and 320px narrow. Natural widths are 900px except three 800px release images. All probes use DPR 1; no alternative rendition or screenshot pixel inspection establishes smaller-image readability or savings. Narrow is a resized existing document, not an independent cold mobile load. At hypothetical DPR 2, 320 CSS px needs 640 physical px.

All six live-dark probes retain light colors despite matching the dark preference; every cold-dark probe initializes dark colors. Body text is preserved. Manual theme toggle activation is untested. All six fresh no-JavaScript text strings exactly equal desktop, and neither width has horizontal overflow. Fonts use a system stack with no web-font entry or response. Twelve Tab steps have visible solid 2px outlines. Print hides global navigation while retaining reading content and screenshots; no pagination or downloaded document was inspected.

Static hashed CSS/JS are gzip-compressed, immutable with max-age=315360000 and ETag. HTML/jsi18n use Brotli. Images expose ETag without captured explicit freshness. Warm reuse/offline behavior is untested. Resource Timing zero image sizes do not mean zero traffic: use staged CDP bytes. CSS usage rows contain observed used rules, not a total stylesheet inventory; no unused-CSS percentage follows. JS source offsets differ from compressed bytes and zero-count ranges are investigation candidates, not safe deletions.

Search journey completes four actions and verifies URL, unique h1 and Manage images text. The legacy successSelectorVisible null is not a failure because completion is satisfied. Autocomplete, pagination, mobile-menu activation, clipboard and feedback are untested. Search is intentionally noindex with no canonical/description. JSON-LD parsing does not establish schema validity; declaredType null is inconclusive because candidate source uses @type=WebPage.

Six raw initial captures sum to 814.923 kB (0.815 MB); arithmetic mean 135.8205 kB and median 61.3665 kB are descriptive unweighted sample statistics, not traffic mix or visitor-session measures. There is one capture per page. SWDM is @tgwf/co2 0.19.0 v4, all first visit, reload ratio 0.02, unknown hosting modeled non-green, provisional protocol. Digital Carbon Ratings differ from WSG scores. No direct energy, traffic or annual footprint is measured.

Wappalyzer heuristically detects Wagtail/Python/Django/Cloudflare/Open Graph, with empty versions, in a separate scan excluded from transfer totals. Cloudflare does not identify origin hosting or renewable electricity. Candidate source is clean tracked revision 31a4547eb1f6de55baea84269723313784f6b544, deployment unverified; lockfiles are metadata only. Exact site fix locations remain hypotheses. /technology lacks its own evidence-index item.

Evidence: staged.json:runs:0–5, probes.json:pages:0–5 and probes.json:journeys:0; source uncertainty is retained in source.json. See evidence.result.json for explicit evidence IDs and requested interpretation changes.
