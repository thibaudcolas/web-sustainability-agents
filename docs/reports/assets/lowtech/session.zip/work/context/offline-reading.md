# Public document capture: offline-reading

Publisher: Low-tech Magazine
Requested source: https://solar.lowtechmagazine.com/offline-reading/
Final source: https://solar.lowtechmagazine.com/offline-reading/
Captured at: 2026-11-06T08:44:54.337Z
HTTP status: 200
Capture method: headless Chromium, rendered main text; no performance measurement.
Limitations: publisher self-report; no independent verification, no internal records. Complete rendered main text within selected page, excluding navigation where main exists.

## Captured source wording

Offline Reading

Read Low-tech Magazine no matter the weather, with no access to a computer, a power supply, or the internet.

Translations fr de nl es it pt pl
Image: Low-tech Magazine: The chronological book series. Photo by Juliette Demaret.  

You prefer to read Low-tech Magazine on paper? We have compiled the articles into several books. Compared to the website, we have partly rewritten some stories, updated all references, and added more or better images.

Print books are for sale through Lulu’s website: chronological edition and thematic collection.
The e-book collection is available via Payhip’s website. Patrons can download e-books (epubs) for free and get early access to new print books at a discounted price.
We also have books for sale in our offices in Barcelona and Brussels.

Below is an overview of our complete book catalog, with links to the corresponding web pages.

Chronological Series

Between 2019 and 2021, we launched a three-volume book series that chronologically ranks Low-tech Magazine’s archives from 2007 to 2021. The series also includes a volume of reader comments on all articles.

In 2025, we published the Compressed Edition, which squeezes the three volumes in just one book of 622 pages. We did this by switching to a smaller font size, by downsizing most images, and by opting for a two-column layout.

In 2026, we redesigned the original (“uncompressed”) series, based on the edits made for the compressed edition. We also published the fourth volume (2022-2026).

Low-tech Magazine Volume IV (2022—2026)
Purchase the paperback
Purchase the hardcover
The Compressed Edition (2007-2021)
Purchase the paperback
Purchase the hardcover
Low-tech Magazine Volume III (2018—2021)
Purchase the paperback
Purchase the hardcover
Get the e-book
Low-tech Magazine Volume II (2012—2018)
Purchase the paperback
Purchase the hardcover
Get the e-book
Low-tech Magazine Volume I (2007—2012)
Purchase the paperback
Purchase the hardcover
Get the e-book
The Comments (2008—2021)
Purchase the paperback
Purchase the hardcover

Thematic Collection

In 2023, we launched a thematic book series, with five volumes now available. These short books open up Low-tech Magazine’s archive by theme rather than chronologically.

Too Much Combustion, Too Little Fire
Purchase the paperback
Get the e-book
How Circular is the Circular Economy?
Purchase the paperback
Get the e-book
Heating People Not Spaces
Purchase the paperback
Get the e-book
How to Downsize a Transport Network?
Purchase the paperback
Get the e-book
How To Build a Low-tech Internet?
Purchase the paperback
Get the e-book

Translated books

All books have been translated into French. One of our books is available in dutch.

Our French Books
Discover the catalogue
Our Dutch Book
Volume III out in dutch
Learn More
Events

Find out where Low-tech Magazine holds talks, workshops and other events.

Translations

Low-tech Magazine is available in several languages: English, French, Spanish, German, Dutch, Polish, and more.

Newsletter

Receive an e-mail whenever Low-tech Magazine publishes a new article.

What is Low-tech Magazine?

Low-tech Magazine underscores the potential of past and often forgotten technologies and how they can inform sustainable energy practices.

## Selected related public links

[]
