# Public document capture: solar-methodology

Publisher: Low-tech Magazine
Requested source: https://solar.lowtechmagazine.com/about/the-solar-website/
Final source: https://solar.lowtechmagazine.com/about/the-solar-website/
Captured at: 2026-11-06T08:44:53.938Z
HTTP status: 200
Capture method: headless Chromium, rendered main text; no performance measurement.
Limitations: publisher self-report; no independent verification, no internal records. Complete rendered main text within selected page, excluding navigation where main exists.

## Captured source wording

About the Solar Powered Website

This website is solar-powered and self-hosted. It has been designed to radically reduce the energy use associated with accessing our content.

Translations fr de nl es it pt
The solar powered server that runs this website.  

Last update: October 21, 2024

Low-tech Magazine questions the belief in technological progress, and highlights the potential of past knowledge and technologies for designing a sustainable society. Because a web redesign was long overdue – and because we try to practice what we preach – we decided to build a low-tech website that meets our needs and abides by our principles.

To reduce energy use, we opted for a back to basics web design, using a static site instead of a database driven content management system. We further apply default typefaces, dithered images, off-line reading options, and other tricks to lower energy use far below that of the average website. In addition, the low resource requirements and open design help to keep the blog accessible for visitors with older computers and/or less reliable Internet connections.

Because it uses so little energy, this website can be run on a mini-computer with the processing power of a mobile phone. It needs 1 to 2.5 watts of power, which is supplied by a small, off-grid solar PV system on the balcony of the author’s home. Typical for off-the-grid renewable power systems, energy storage is limited. This means that the website will go off-line during longer periods of cloudy weather.

Why a low-tech website?

Why does it go off-line?

How often is it off-line?

When is the best time to visit?

How is the website designed?

Which hardware and software do you use?

Who made this?

Comments

The solar powered website in the media

Why a low-tech website?

We were told that the Internet would “dematerialise” society and decrease energy use. Contrary to this projection, it has become a large and rapidly growing consumer of energy itself. According to the latest estimates, the entire network already consumes 10% of global electricity production, with data traffic doubling roughly every two years.

In order to offset the negative consequences associated with high energy consumption, renewable energy has been proposed as a means to lower emissions from powering data centers. For example, Greenpeace’s yearly ClickClean report ranks major Internet companies based on their use of renewable power sources.

However, running data centers on renewable power sources is not enough to address the growing energy use of the Internet. To start with, the Internet already uses three times more energy than all wind and solar power sources worldwide can provide. Furthermore, manufacturing, and regularly replacing, renewable power plants also requires energy, meaning that if data traffic keeps growing, so will the use of fossil fuels.

Finally, solar and wind power are not always available, which means that an Internet running on renewable power sources would require infrastructure for energy storage and/or transmission that is also dependent on fossil fuels for its manufacture and replacement. Powering websites with renewable energy is not a bad idea. However, the trend towards growing energy use must also be addressed.

Websites are getting “fatter”

The growing energy use of the Internet is associated with two trends. First, content is becoming increasingly resource-intensive. This has a lot to do with the growing importance of video, but a similar trend can be observed among websites.

The size of the average web page (defined as the average page size of the 500,000 most popular websites) increased from 0.45 megabytes in 2010 to 1.7 megabytes in June 2018. For mobile websites, the average “page weight” rose tenfold from 0.15 MB in 2011 to 1.6 MB in 2018. Using different measurement methods, other sources report average page sizes of up to 2.9 MB in 2018.

The size of the average web page increased at least threefold from 2010 to 2018.

The growth in data traffic surpasses the advances in energy efficiency (the energy required to transfer 1 megabyte of data over the Internet), resulting in more and more energy use.

Over and above this, “heavier” or “larger” websites not only increase energy use in the network infrastructure, but they also shorten the lifetime of computers – larger websites require more powerful computers to access them. This means that more computers need to be manufactured, which is a very energy-intensive process.

Always online

A second reason for growing Internet energy consumption is that we spend more and more time on-line. Before the arrival of portable computing devices and wireless network access, we were only connected to the network when we had access to a desktop computer in the office, at home, or in the library. We now live in a world in which no matter where we are, we are always on-line, including, at times, via more than one device simultaneously.

Continuous network access doesn’t combine well with renewable energy sources such as wind and solar power, which are not always available.

“Always-on” Internet access is accompanied by a cloud computing model – allowing more energy efficient user devices at the expense of increased energy use in data centers. Increasingly, activities that could perfectly happen off-line – such as writing a document, filling in a spreadsheet, or storing data – are now requiring continuous network access. This does not combine well with renewable energy sources such as wind and solar power, which are not always available.

Addressing both issues

Our new web design addresses both these issues. Thanks to a low-tech web design, we managed to decrease the average page size of the blog by a factor of five compared to the old design – all while making the website visually more attractive. Secondly, our new website runs 100% on solar power, not just in words, but in reality: it has its own energy storage and will go off-line during longer periods of cloudy weather.

The 50W and 30W solar PV panels on the balcony. One is powering the website, the other is powering the lights in the living room. Image by Marie Verdeil.  
How is the website designed?

The Internet is not an autonomous being. Its growing energy use is the consequence of actual decisions made by software developers, web designers, marketing departments, publishers and internet users. With a lightweight, off-grid solar-powered website, we want to show that other decisions can be made.

The average page size of this website is below 0.5 MB – roughly a sixth of the average page size of the original website

With about 100 articles online, the average page weight on the solar powered website is now below 0.5 MB – roughly a fifth of the average page size of the previous design, and less than three times the average page size of the 500,000 most popular blogs in June 2018. The page weight for each article on this website is shown in the lower left corner of the screen.

Below are some of the design decisions we made to reduce energy use. We have published a separate document that focuses on the front-end efforts, and one that focuses on the back-end. We have also released the source code for our website design.

Static Site Generator

One of the fundamental choices we made was to build a static website. Most of today’s websites use server side programming languages that generate the website on the fly by querying a database. This means that every time someone visits a web page, it is generated on demand.

On the other hand, a static website is generated once and exists as a simple set of documents on the server’s hard disc. It’s always there – not just when someone visits the page. Static websites are thus based on file storage whereas dynamic websites depend on recurrent computation. Static websites consequently require less processing power and thus less energy.

A static website requires less processing power because it is not dependent on recurrent computation

The choice for a static site enables the possibility of serving the site in an economic manner from our home office in Barcelona. Doing the same with a database-driven website would be nearly impossible, because it would require too much energy. It would also be a big security risk. Although a web server with a static site can be hacked, there are significantly less attack routes and the damage is more easily repaired.

Dithered Images

The main challenge was to reduce page size without making the website less attractive. Because images take up most of the bandwidth, it would be easy to obtain very small page sizes and lower energy use by eliminating images, reducing their number, or making them much smaller. However, visuals are an important part of Low-tech Magazine’s appeal, and the website would not be the same without them.

By dithering, we can make images ten times less resource-intensive, even though they are displayed much larger than on the old website.

Instead, we chose to apply an obsolete image compression technique called “dithering”. The number of colours in an image, combined with its file format and resolution, contributes to the size of an image. Thus, instead of using full-colour high-resolution images, we chose to convert all images to black and white, with four levels of grey in-between. These black-and-white images are then coloured according to the pertaining content category via the browser’s native image manipulation capacities.

The solar powered server in its new housing, screwed against the wall in the living room. The battery is in front. The solar charge controller below the laptop powers the lights in the room. Image by Marie Verdeil.  

Compressed through this dithering plugin, images featured in the articles add much less load to the content: compared to the old website, the images are roughly ten times less resource-intensive.

Default typeface / No logo

All resources loaded, including typefaces and logos, are an additional request to the server, requiring storage space and energy use. Therefore, our new website does not load a custom typeface and removes the font-family declaration, meaning that visitors will see the default typeface of their browser. Only one weight (regular) of a font is used, demonstrating that content hierarchy can be communicated without loading multiple typefaces and weights.

Visitors will see the default typeface of their browser, eliminating the need to load a custom typeface.

We use a similar approach for the logo. In fact, Low-tech Magazine never had a real logo, just a banner image of a spear held as a low-tech weapon against prevailing high-tech claims. Instead of a designed logotype, which would require the production and distribution of custom typefaces and imagery, Low-tech Magazine’s new identity consists of a single typographic move: to use the left-facing arrow in place of the hypen in the blog’s name: LOW←TECH MAGAZINE. This pared-down identity drew inspiration from the past as well as the banner image of the previous design.

Why does it go offline?

Quite a few web hosting companies claim that their servers are running on renewable energy. However, even when they actually generate solar power on-site, and do not merely “offset” fossil fuel power use by planting trees or the like, their websites are always online.

This means that either they have a giant battery storage system on-site (which makes their power system unsustainable), or that they are relying on grid power when there is a shortage of solar power (which means that they do not really run on 100% solar power).

Keeping the server on-line no matter what simply requires too many batteries, which makes the system unsustainable and expensive.

In contrast, this website runs on an off-the-grid solar power system with its own energy storage, and will go off-line during longer periods of cloudy weather. Less than 100% reliability is essential for the sustainability of an off-the-grid solar system, because above a certain threshold the fossil fuel energy used for producing and replacing the batteries is higher than the fossil fuel energy saved by the solar panels.

Apart from sustainability (and costs), the author’s home has limited space for installing solar panels and batteries. Keeping the server on-line no matter what – the standard business model of webhosting companies – simply requires too many batteries.

 
The sizing of battery and solar panel is a compromise between uptime and sustainability. Illustration: Diego Marmolejo  
How often is it offline?

Over a period of roughly one year (351 days, from 12 December 2018 to 28 November 2019) the server was up for 95.26% of the time. This means that we were offline for 399 hours (which corresponds to 16.64 days).

These numbers don’t tell the whole story, though. During the first ten months of this period, the server was online for 98.2% of the time. This means that it was offline for only 152 hours (6.4 days) – and this includes the winter months.

However, uptime from 1 October to 30 November 2019 plummeted to 80.17%. This was caused by a software upgrade of the Linux kernel, which increased the average power use of the server from 1.19 to 1.49 watts, and consequently brought the website down for at least a few hours every night.

Image: In October 2019, average power use suddenly increases and the site goes down every night.  

The graph above, which shows the power use of the server from 15 July to 15 November 2019, reveals the effect of the software upgrade. Power use is zero when the server is offline. Before the software upgrade, this happens only now and then, during longer periods of bad weather. From October onwards, it happens every night. The two peaks at the beginning of November show two intents to charge the battery with grid power, because we initially assumed the problem was caused by a deteriorating battery.

All the data above refer to a set-up consisting of a 50W solar panel with an energy storage capacity that is equivalent to that of an 86.4 Wh lead-acid battery. In December 2019 and January 2020, we have been running the system on different sizes of solar panels and batteries. Based on these experiments, we decided to continue with a smaller (30W) solar panel and a larger (168 Wh) lead-acid battery. Since then, the uptime has been 100% (March to September 2020), even though we have added a lot of content by making the website multilingual. This is due to the larger (brand new) battery but also to the better orientation of the smaller solar panel. The battery’s capacity will decline over time, so the higher storage capacity will make it last longer. If the uptime remains 100% through the winter 2020/2021, we will probably downgrade to a 20W solar panel.

Here’s a graphic representation of our uptime in 2020, related to the weather.

When is the best time to visit?

The accessibility of this website depends on the weather in Barcelona, Spain, where the solar-powered web server is located. Because it is solar powered, the website is most often online during the summer. To help visitors “plan” their visits to Low-tech Magazine, we provide them with several pointers.

A battery meter provides crucial information because it may tell the visitor that the blog is about to go down – or that it’s “safe” to read it. The design features a background colour that indicates the capacity of the solar-charged battery that powers the website server. A decreasing height indicates that night has fallen or that the weather is bad.

To help visitors “plan” their visits to Low-tech Magazine, we provide them with several pointers such as a battery meter and a weather forecast.

In addition to the battery level, other information about the website server is visible with a statistics dashboard. This includes contextual information of the server’s location: time, current sky conditions, upcoming forecast, and the duration since the server last shut down due to insufficient power.

To access Low-tech Magazine no matter the weather, we have several offline reading options available. These include four printed volumes with a total of 2,398 pages and 709 images.

The Printed Website.  
Which hardware and software do you use?

We wrote four extra articles with more in-depth technical information:

How to build a low-tech website: software and hardware, which focuses on the back-end.
How to Build a Low-tech Website: Design Techniques and Process, which focuses on the front-end.
How to build a small solar power system, which explains the building of the solar power part.
How sustainable is a solar powered website?, which focuses on the sizing of the solar PV system and the optimal balance between uptime and sustainability.

In addition, Roel Roscam Abbing wrote a conference paper about Low-tech Magazine’s solar powered website: ‘This is a solar-powered website, which means it sometimes goes offline’: a design inquiry into degrowth and ICT.” Workshop on Computing within Limits. 2021.

SERVER: This website runs on an Olimex A20 computer. It has 2 Ghz of processing power, 1 GB of RAM, and 16 GB of storage. The server draws 1 - 2.5 watts of power.

SERVER SOFTWARE: The webserver runs Armbian Stretch, a Debian based operating system built around the SUNXI kernel. We wrote technical documentation for configuring the webserver.

DESIGN SOFTWARE: The website is built with Pelican, a static site generator. We have released the source code for ‘solar’, the Pelican theme we developed here.

INTERNET CONNECTION. The server is connected to a 100 MBps fibre internet connection. Here’s how we configured the router. For now, the router is powered by grid electricity and requires 10 watts of power. We are investigating how to replace the energy-hungry router with a more efficient one that can be solar-powered, too.

SOLAR PV SYSTEM. At the moment, the server runs on a 30W solar panel and a 168 Wh lead-acid battery. However, we keep experimenting with different setups. The PV installation is managed by a 10A solar charge controller.

Who made this website?

Web design and development: Marie Otsuka, Roel Roscam Abbing.

Computer hardware: Roel Roscam Abbing.

Solar hardware: Kris De Decker.

Content production & translations: Kathy Vanhout.

Website maintenance: Marie Verdeil.

Advertising services, which have maintained Low-tech Magazine since its start in 2007, are not compatible with our lightweight web design. Therefore, we are searching for other ways to finance the website:

We offer print-on-demand copies of the website. These publications allow you to read Low-tech Magazine on paper, on the beach, in the sun, or whenever and where ever you want. We also offer ebooks.
You can support us through PayPal, Patreon and LiberaPay. Patrons get early access to new books, book promotions, special editions, and more.
The solar powered website in the media

“Cleaner, Faster, Greener: Rethinking How We Build Websites”, LACMA’s blog Unframed, 2025.

“How to build a solar powered website?”, Justine Paradis, Outside/In, New Hampshire Public Radio, 2022

“Can the Internet Survive Climate Change?”, Kevin Lozano, The New Republic, 2019

“The future of web design is less, not more”, Kelsey Campbell-Dollaghan, Fastcompany, September 10, 2018.

“Imagining a Solar-Powered Internet: Kris De Decker Low<–Tech Magazine”, Jasio Stefanski, The Gradient, Walker Art Magazine, November 21, 2018.

“Interview: Marie Otsuka. Podcast, HTML.energy, December 2019

“How to Build a Low-Tech Website”, Roman Zolotarev, Hacker News, 2018.

“Low-Tech Magazine switches to a low-tech, low carbon website”, Lloyd Alter, Treehugger, September 26, 2018.

“The philosophy of low-tech: a conversation with Kris De Decker”, Aaron Vansintjan, Never Apart Magazine, July 2019.

“Reconsider the thinking that everything should become digital”, Svensk biblioteksförening, March 2020.

“Perfecting the solar powered web server”, Tom Nardi, Hackaday, October 8, 2018.

“This Solar-Powered, ‘Low Tech’ Website Goes Offline When It’s Cloudy”, Slashdot, October 2, 2018.

“The Internet’s Carbon Footprint”, IRL Mozilla Firefox Podcast, July 2019.

“The Solar-Powered Website Offering a Vision for an Eco-Friendly Internet”, Leander Jones, RESET, April 2020

“Low-tech Magazine website”, Matthijs Sluiter, Fonts in use, January 9, 2019.

“Low-tech Magazine’s Solar-Powered Website is Rewriting the Rules of Web Design”, Liz Stinson, Aiga Eye on Design, November 12, 2018.

“YouTube’s carbon footprint is huge, but smarter web design could fix it”, Nicole Kobie, Wired, May 7, 2019.

“How an online magazine avoids the internet’s impact on the environment”, Alexandria Neason, Columbia Journalism Review, April 30, 2019.

“Kris De Decker on web design’s energy-efficient future”, Kathryn Bishop, LSN Global, October 25, 2018.

“A solar-powered, self-hosted version of Low-Tech Magazine”, Hemmert (pseudonym), Hacker News, April 2019.

“A website that runs on a solar-powered server in Barcelona”, Peey (pseudonym), Hacker News, May 2019.

“Solar Powered Website”, Ars Electronica, Ars Electronica Prix 2019.

“Low-tech Magazine and a better internet for the Anthropocene”, Naomi Huffman, MCD Books, April 9, 2019.

“The Future of Websites? How one site has Gone 100% Solar”, S. Fraser, Seabr0 .

“Restart Podcast Ep. 53: Our low-tech future with Kris De Decker”, Restart, May 2020.

Off-line portal to the solar powered website at the Dutch Design Week in Eindhoven. Designed and built in collaboration with Marie Verdeil. More images here.  
Other low-tech websites:

“Dries Buytaert” (founder of Drupal), October 2024

“Solar Protocol”, March 2021

“Formafantasma”, February 2021

“Ontaarde Beschaving, 2021

“Post Growth Toolkit”, November 2020

“Low Tech Lab”, October 2020

“Branch”, October 2020

“Chaire Diament, Université du Québec, 2020

“Louwrentius”, July 2020

“Finding Pleasure in Scarcity”, Daniel Parnitzke!, May 2020

“Digital guide to low tech”, Gauthier Roussilhe, Gauthier Roussilhe Writings, March 11, 2019.

“Our lighter website”, Caroline Whyte, Feasta, July 16, 2019

“Fisk Solar”, A solar powered website in Sourhall, Todmorden, Yorkshire, UK, 2019

“Solar powered media project”, 2019

Media links in French:

“Pour un Web Frugal”, Framalang (pseudonym), Framablog, January 24, 2019.

“Le design pour lutter contre le changement climatique”, Hubert Guillaud, internetactu.net, September 18, 2019

“Environnement : un site internet fonctionne à l’énergie solaire”, Caroline Drzewinski, RTL Online, October 10, 2018.

“Quel avenir pour les sites « low-tech » ?”, Geoffrey Dorne, Grafisme et interactivité, September 1, 2019

“Relier numérique et low tech”, Fing, Agenda pour un futur numérique et écologique, Défi No. 13, March 2019.

“Faire tourner un site web à l’énergie solaire”, Claire, L’assembleuse, November 15, 2018.

“Ce site est tellement low tech qu’il est hors ligne quand il n’y a pas de soleil, Numerama, October 2018

Media links in Spanish

“Si internet quiere ser sostenible, necesita adelgazar”, El Pais, February 15, 2020

“Low tech magazine, un sitio web sostenible”, Cátedra Telefónica-UOC de Diseno y Creación Multimedia, October 10, 2018.

“Esta página web funciona con energía solar y consume menos debido a su diseño”, Alicia Ruiz Fernández, Ticbeat, 9 october 2018.

Media links in German

“Wie du einen mit Photovoltaik angetriebenen Webserver baust”, Thomas Reis, Spandauer Volksblatt, September 26, 2018.

“Solarbetrieben: Bei schlechtem Wetter ist diese Website offline”, Kim Rixecker, t3n, October 9, 2018.

“Diese radikal nachhaltige Webseite zeigt, wie ein umweltfreundliches Internet aussehen könnte”, Leander Jones, RESET, May 2020.

“Low-Tech-Website geht offline, wenn die Wolken aufziehen”, Helga Hansen, Heise Online, October 12, 2018.

“Wie das Internet Strom frisst”, Philip Bovermann, Süddeutsche Zeitung, August 28, 2019.

“How to build a solar powered website?” A Bits & Bäume 2018 Podiumsdiskussion by Kris De Decker, media.ccc.de, November 18, 2018 (mediafile).

In other languages

“Uma revista com muitas dúvidas sobre a tecnologia”, João PedroPerera, Publico, May 5, 2019.

“Low Tech Magazine gaat terug naar zijn roots”, Branko Collin, 2019.

The solar powered website in the Design Museum in London. It forms part of the exhibition “Waste age: what can design do?“, which runs until 20 February 2022.  
Reactions

To make a comment, please send an e-mail to solar (at) lowtechmagazine (dot) com. Your e-mail address is not used for other purposes, and will be deleted after the comment is published. If you don’t want your real name to be published, sign the e-mail with the name you want to appear.

146 Reactions

## Selected related public links

[
  {
    "text": "The solar powered website in the media",
    "href": "https://solar.lowtechmagazine.com/about/the-solar-website/#media"
  },
  {
    "text": "essential for the sustainability of an off-the-grid solar system",
    "href": "https://solar.lowtechmagazine.com/2020/01/how-sustainable-is-a-solar-powered-website.html"
  },
  {
    "text": "different sizes of solar panels and batteries",
    "href": "https://solar.lowtechmagazine.com/2020/01/how-sustainable-is-a-solar-powered-website.html"
  },
  {
    "text": "several offline reading options available",
    "href": "https://solar.lowtechmagazine.com/offline-reading.html"
  },
  {
    "text": "How to build a small solar power system",
    "href": "https://solar.lowtechmagazine.com/2023/12/how-to-build-a-small-solar-power-system/"
  },
  {
    "text": "How sustainable is a solar powered website?",
    "href": "https://solar.lowtechmagazine.com/2020/01/how-sustainable-is-a-solar-powered-website.html"
  },
  {
    "text": "‘This is a solar-powered website, which means it sometimes goes offline’: a design inquiry into degrowth and ICT",
    "href": "https://computingwithinlimits.org/2021/papers/limits21-abbing.pdf"
  },
  {
    "text": "released the source code for ‘solar’, the Pelican theme we developed here",
    "href": "https://github.com/lowtechmag/solar"
  },
  {
    "text": "How to build a solar powered website?",
    "href": "http://outsideinradio.org/shows/how-to-build-a-solar-powered-website"
  },
  {
    "text": "Imagining a Solar-Powered Internet: Kris De Decker Low<–Tech Magazine",
    "href": "https://walkerart.org/magazine/low-tech-magazine-kris-de-decker"
  },
  {
    "text": "Perfecting the solar powered web server",
    "href": "https://hackaday.com/2018/10/08/perfecting-the-solar-powered-web-server/"
  },
  {
    "text": "This Solar-Powered, ‘Low Tech’ Website Goes Offline When It’s Cloudy",
    "href": "https://tech.slashdot.org/story/18/10/02/1739237/this-solar-powered-low-tech-website-goes-offline-when-its-cloudy"
  },
  {
    "text": "The Solar-Powered Website Offering a Vision for an Eco-Friendly Internet",
    "href": "https://en.reset.org/blog/solar-powered-website-offering-vision-eco-friendly-internet-04232020"
  },
  {
    "text": "Low-tech Magazine’s Solar-Powered Website is Rewriting the Rules of Web Design",
    "href": "https://eyeondesign.aiga.org/low-tech-magazines-solar-powered-website-is-rewriting-the-rules-of-web-design/"
  },
  {
    "text": "A solar-powered, self-hosted version of Low-Tech Magazine",
    "href": "https://news.ycombinator.com/item?id=19407847"
  },
  {
    "text": "A website that runs on a solar-powered server in Barcelona",
    "href": "https://news.ycombinator.com/item?id=20038619"
  },
  {
    "text": "Solar Powered Website",
    "href": "https://calls.ars.electronica.art/prix2019/prixwinner/32502/"
  },
  {
    "text": "The Future of Websites? How one site has Gone 100% Solar",
    "href": "http://www.seabro.it/the-future-of-websites-how-one-site-has-gone-100-solar/"
  },
  {
    "text": "Solar Protocol",
    "href": "http://solarprotocol.net/index.html"
  },
  {
    "text": "Fisk Solar",
    "href": "http://fisksolar.ddns.net/"
  },
  {
    "text": "Solar powered media project",
    "href": "https://wp.nyu.edu/solarpoweredmedia/"
  },
  {
    "text": "Esta página web funciona con energía solar y consume menos debido a su diseño",
    "href": "https://www.ticbeat.com/innovacion/esta-pagina-web-funciona-con-energia-solar-y-consume-menos-gracias-a-su-diseno/"
  },
  {
    "text": "Solarbetrieben: Bei schlechtem Wetter ist diese Website offline",
    "href": "https://t3n.de/news/solarbetriebene-website-server-1116595/"
  },
  {
    "text": "Low-Tech-Website geht offline, wenn die Wolken aufziehen",
    "href": "https://www.heise.de/make/meldung/Low-Tech-Webseite-geht-offline-wenn-die-Wolken-aufziehen-4183293.html?hg=1&hgi=3&hgf=false"
  },
  {
    "text": "How to build a solar powered website?",
    "href": "https://media.ccc.de/v/bub2018-365-how_to_build_a_solar_powered_website#t=103"
  }
]
