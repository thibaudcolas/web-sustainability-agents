# Public document capture: archive

Publisher: Low-tech Magazine
Requested source: https://solar.lowtechmagazine.com/archives/
Final source: https://solar.lowtechmagazine.com/archives/
Captured at: 2026-11-06T08:44:54.426Z
HTTP status: 200
Capture method: headless Chromium, rendered main text; no performance measurement.
Limitations: publisher self-report; no independent verification, no internal records. Complete rendered main text within selected page, excluding navigation where main exists.

## Captured source wording

Archive
Filter by Theme
DATE 
TITLE
CATEGORY
September 24, 2026
Out Now: Low-tech Magazine Volume IV
Low-tech Solutions
April 22, 2026
Rediscovering the Handcart
Low-tech Solutions
March 30, 2026
Low-tech Magazine: The Uncompressed Book Series
Obsolete Technology
November 16, 2025
Winter is Coming: Build a Solar Powered Foot Stove
Low-tech Solutions
November 9, 2025
How to Brew Solar Powered Coffee
Low-tech Solutions
November 4, 2025
Thematic Book Series: Too Much Combustion, Too Little Fire
High-tech Problems
October 13, 2025
How to Build a Solar Powered Electric Oven
Low-tech Solutions
October 12, 2025
How to Assemble an Electric Heating Element from Scratch
Low-tech Solutions
July 9, 2025
How to Mount a Balcony Awning
Low-tech Solutions
June 16, 2025
How to Dress and Undress your Home
Obsolete Technology
March 20, 2025
The Compressed Book Edition
High-tech Problems
December 22, 2024
How to Build an Electrically Heated Table?
Low-tech Solutions
September 17, 2024
Communal Luxury: The Public Bathhouse
Low-tech Solutions
July 23, 2024
Low-tech Magazine: The Ebooks
Low-tech Solutions
July 22, 2024
Thematic Book Series: How Circular is the Circular Economy?
Obsolete Technology
March 18, 2024
How to Escape From the Iron Age?
High-tech Problems
December 27, 2023
How to Build a Small Solar Power System
Low-tech Solutions
December 7, 2023
Thematic Book Series: Heating People, not Spaces
High-tech Problems
December 1, 2023
Test our Bike Generators in Paris, Rotterdam, and Barcelona
Low-tech Solutions
November 16, 2023
Plastic Waste in the Fuel Tank?
High-tech Problems
October 7, 2023
Thematic Book Series: How to Downsize a Transport Network?
Obsolete Technology
October 6, 2023
Workshop in Rotterdam: How to Build a Bike Generator
Low-tech Solutions
August 25, 2023
Direct Solar Power: Off-Grid Without Batteries
Low-tech Solutions
August 18, 2023
Thematic Book Series: How to Build a Low-tech Internet?
High-tech Problems
July 9, 2023
Human Powered Air Compressor and Energy Storage System
Low-tech Solutions
June 13, 2023
Rebuilding a Solar Powered Website
Low-tech Solutions
June 8, 2023
Low-tech Magazine: The Comic
Low-tech Solutions
February 28, 2023
Can We Make Bicycles Sustainable Again?
High-tech Problems
November 23, 2022
What if We Replace Guns and Bullets with Bows and Arrows?
Low-tech Solutions
November 22, 2022
When Lethal Weapons Grew on Trees
Obsolete Technology
March 6, 2022
How to Build a Practical Household Bike Generator
Low-tech Solutions
January 20, 2022
The Revenge of the Hot Water Bottle
Obsolete Technology
December 2, 2021
The Printed Website: Volume III & The Comments
Low-tech Solutions
November 3, 2021
Fascine Mattresses: Basketry Gone Wild
Obsolete Technology
October 5, 2021
How to Build a Low-tech Solar Panel?
Low-tech Solutions
May 11, 2021
How to Design a Sailing Ship for the 21st Century?
Low-tech Solutions
March 28, 2021
Urban Fish Ponds: Low-tech Sewage Treatment for Towns and Cities
Obsolete Technology
February 18, 2021
How Sustainable is High-tech Health Care?
High-tech Problems
February 16, 2021
Vertical Farming Does not Save Space
High-tech Problems
December 20, 2020
How and Why I Stopped Buying New Laptops
High-tech Problems
September 20, 2020
How to Make Biomass Energy Sustainable Again
Obsolete Technology
May 26, 2020
Thermoelectric Stoves: Ditch the Solar Panels?
Low-tech Solutions
April 16, 2020
Fruit Trenches: Cultivating Subtropical Plants in Freezing Temperatures
Obsolete Technology
January 28, 2020
How Sustainable is a Solar Powered Website?
Low-tech Solutions
January 27, 2020
The Solar Powered Website in Spanish, French, and Other Languages
High-tech Problems
December 29, 2019
Too Much Combustion, Too Little Fire
Obsolete Technology
December 8, 2019
The Printed Website: Second Volume Out Now
High-tech Problems
October 17, 2019
Mist Showers: Sustainable Decadence?
Low-tech Solutions
June 2, 2019
Reinventing the Small Wind Turbine
Low-tech Solutions
June 2, 2019
How to Make Wind Power Sustainable Again
High-tech Problems
March 31, 2019
Low-tech Magazine: The Printed Website
Obsolete Technology
February 27, 2019
Heat your House with a Mechanical Windmill
Low-tech Solutions
December 9, 2018
Keeping Some of the Lights On: Redefining Energy Security
Low-tech Solutions
November 3, 2018
How Circular is the Circular Economy?
High-tech Problems
September 24, 2018
How to Build a Low-tech Website?
Low-tech Solutions
August 5, 2018
Could We Dredge the Netherlands Without Fossil Fuels?
Obsolete Technology
July 25, 2018
The Messy World of Fermentation
Low-tech Solutions
July 5, 2018
We Can't Do It Ourselves
High-tech Problems
May 16, 2018
Ditch the Batteries: Off-Grid Compressed Air Energy Storage
Low-tech Solutions
May 15, 2018
History and Future of the Compressed Air Economy
Obsolete Technology
January 24, 2018
How Much Energy Do We Need?
Low-tech Solutions
January 13, 2018
Energy labels oblige frugal homeowners to make unsustainable investments
High-tech Problems
January 9, 2018
Bedazzled by Energy Efficiency
High-tech Problems
September 21, 2017
How to Run the Economy on the Weather
Low-tech Solutions
September 13, 2017
How (Not) to Run a Modern Society on Solar and Wind Power Alone
High-tech Problems
August 24, 2017
Non-Electric Hearing Aids Outperform Modern Devices
Obsolete Technology
May 28, 2017
Could We Run Modern Society on Human Power Alone?
Low-tech Solutions
March 17, 2017
Heat Storage Hypocausts: Air Heating in the Middle Ages
Obsolete Technology
February 20, 2017
Vietnam's Low-tech Food System Takes Advantage of Decay
Low-tech Solutions
February 20, 2017
Rebooting Energy Demand: Automatic Software Upgrades
High-tech Problems
February 12, 2017
Medieval Heating System Lives on in Spain
Obsolete Technology
November 22, 2016
Why the Office Needs a Typewriter Revolution
Low-tech Solutions
November 22, 2016
The Curse of the Modern Office
High-tech Problems
October 25, 2016
Pigeon Towers: A Low-tech Alternative to Synthetic Fertilizers
Obsolete Technology
May 17, 2016
How to Get Your Apartment Off the Grid
Low-tech Solutions
April 27, 2016
Slow Electricity: The Return of DC Power?
Low-tech Solutions
March 30, 2016
Power Water Networks
Obsolete Technology
December 24, 2015
Reinventing the Greenhouse
Low-tech Solutions
December 24, 2015
Fruit Walls: Urban Farming in the 1600s
Obsolete Technology
October 26, 2015
How to Build a Low-tech Internet
Low-tech Solutions
October 25, 2015
The 4G Mobile Internet That's Already There
Low-tech Solutions
October 19, 2015
Why We Need a Speed Limit for the Internet
High-tech Problems
October 13, 2015
Garum: Fermented Fish Sauce for the Ancient Roman Masses
Obsolete Technology
June 17, 2015
Water Johads: A Low-Tech Alternative to Mega-Dams in India
Low-tech Solutions
May 3, 2015
How Sustainable is Stored Sunlight?
High-tech Problems
April 26, 2015
How Sustainable is PV solar power?
High-tech Problems
March 11, 2015
Radiant & Conductive Heating Systems
Low-tech Solutions
March 11, 2015
How to Keep Warm in a Cool House
Low-tech Solutions
February 11, 2015
Restoring the Old Way of Warming: Heating People, not Places
Obsolete Technology
September 10, 2014
The Revenge of the Circulating Fan
Low-tech Solutions
July 1, 2014
If We Insulate Our Houses, Why Not Our Cooking Pots?
Low-tech Solutions
June 23, 2014
Well-Tended Fires Outperform Modern Cooking Stoves
High-tech Problems
May 5, 2014
Modular Cargo Cycles
Low-tech Solutions
March 25, 2014
How Sustainable is Digital Fabrication?
High-tech Problems
December 16, 2013
High Speed Trains are Killing the European Railway Network
High-tech Problems
November 6, 2013
Heat Your Clothes, Not Your House
Low-tech Solutions
September 30, 2013
Burning the Bones of the Earth: Lime Kilns
Obsolete Technology
September 9, 2013
Power from the Tap: Water Motors
Obsolete Technology
August 11, 2013
Back to Basics: Direct Hydropower
Low-tech Solutions
March 2, 2013
The Mechanical Transmission of Power (3): Endless Rope Drives
Obsolete Technology
February 2, 2013
The Mechanical Transmission of Power (2): Jerker Line Systems
Obsolete Technology
January 23, 2013
The Mechanical Transmission of Power (1): Stangenkunst
Obsolete Technology
December 15, 2012
How to Make Everything Ourselves: Open Modular Hardware
Low-tech Solutions
October 24, 2012
Electric Velomobiles: as Fast and Comfortable as Automobiles, but 80 times more Efficient (Part Two)
Low-tech Solutions
October 24, 2012
Electric Velomobiles: as Fast and Comfortable as Automobiles, but 80 times more Efficient
Low-tech Solutions
September 24, 2012
Cargo Cyclists Replace Truck Drivers on European City Streets
Low-tech Solutions
April 25, 2012
How to Keep Beverages Cool Outside the Refrigerator
Low-tech Solutions
March 24, 2012
The Solar Envelope: How to Heat and Cool Cities without Fossil Fuels
Low-tech Solutions
February 24, 2012
The Art of Producing Sustainable Consumer Goods: Basketry
Obsolete Technology
December 29, 2011
How to Downsize a Transport Network: The Chinese Wheelbarrow
Obsolete Technology
November 13, 2011
Gas Bag Vehicles
Obsolete Technology
September 29, 2011
Medieval Smokestacks: Fossil Fuels in Pre-industrial Times
Obsolete Technology
July 26, 2011
The Bright Future of Solar Thermal Powered Factories
Low-tech Solutions
May 25, 2011
The Short History of Early Pedal Powered Machines
Obsolete Technology
May 25, 2011
Pedal Powered Farms and Factories: The Forgotten Future of the Stationary Bicycle
Low-tech Solutions
May 25, 2011
Commercially Available Bike Generators Are Not Sustainable
High-tech Problems
February 27, 2011
Insulation: First the Body, Then the Home
Low-tech Solutions
January 26, 2011
Aerial Ropeways: Automatic Cargo Transport for a Bargain
Obsolete Technology
December 15, 2010
Hand Powered Drilling Tools and Machines
Obsolete Technology
November 16, 2010
Boat Mills: Water Powered, Floating Factories
Obsolete Technology
September 30, 2010
The Velomobile: High-tech Bike or Low-tech Car?
Low-tech Solutions
September 15, 2010
Recycling Animal and Human Dung is the Key to Sustainable Farming
Low-tech Solutions
September 5, 2010
Piston-powered aircraft from the 1950s were as fuel-efficient as the current average jet
High-tech Problems
June 28, 2010
Lost Knowledge: Ropes and Knots
Obsolete Technology
June 28, 2010
How to tie the world together: online knotting reference books
Obsolete Technology
May 3, 2010
The Status Quo of Electric Cars: Better Batteries, Same Range
High-tech Problems
April 22, 2010
Overview of Early Electric Cars (1895-1925)
Obsolete Technology
March 25, 2010
The Sky is the Limit: Human-Powered Cranes and Lifting Devices
Obsolete Technology
January 18, 2010
Wood Gas Vehicles: Firewood in the Fuel Tank
Obsolete Technology
December 15, 2009
Trolley Canal Boats
Obsolete Technology
November 18, 2009
How (Not) To Resolve the Energy Crisis
High-tech Problems
October 26, 2009
Cars: out of the way
Low-tech Solutions
October 19, 2009
Rings of Fire: Hoffmann Kilns
Obsolete Technology
October 18, 2009
How to make everything yourself - online low-tech resources
Low-tech Solutions
October 8, 2009
Wind Powered Factories: History (and Future) of Industrial Windmills
Obsolete Technology
September 17, 2009
Water Powered Cable Trains
Obsolete Technology
July 10, 2009
Get Wired (Again): Trolleybuses and Trolleytrucks
Low-tech Solutions
July 9, 2009
Electric Road Trains
Obsolete Technology
June 16, 2009
The Monster Footprint of Digital Technology
High-tech Problems
June 14, 2009
How much energy does it take (on average) to produce 1 kilogram of the following materials?
High-tech Problems
April 19, 2009
Small Windmills Put to the Test
High-tech Problems
April 13, 2009
Sailing at the Touch of a Button
Low-tech Solutions
April 12, 2009
Cargo Ships, Then and Now
Low-tech Solutions
March 10, 2009
Who Killed the Electric Grid? Fast-charging Electric Cars
High-tech Problems
February 19, 2009
The Museum of Old Techniques
Obsolete Technology
February 13, 2009
Truckloads of Hard Disks
High-tech Problems
February 9, 2009
Camping in the clouds: the Aeromodeller II
Low-tech Solutions
January 19, 2009
Moonlight Towers: Light Pollution in the 1800s
Obsolete Technology
December 21, 2008
Only idiots travel by train
High-tech Problems
December 5, 2008
Sunbathing in the Living Room: Oven Stoves and Heat Walls
Low-tech Solutions
November 25, 2008
How to Build a Floating Trash Island
Low-tech Solutions
November 12, 2008
Tiles as a Substitute for Steel: The Art of the Timbrel Vault
Obsolete Technology
October 14, 2008
Viva Las Vegas: LEDs and the energy efficiency paradox
High-tech Problems
September 11, 2008
The Age of Speed: How to Reduce Global Fuel Consumption by 75 Percent
Low-tech Solutions
September 2, 2008
Urban windmills harm the environment
High-tech Problems
August 24, 2008
A Steam Powered Submarine: The Ictíneo
Obsolete Technology
June 29, 2008
Carbon sequestration: Bury the Idea, not the CO2
High-tech Problems
June 6, 2008
The Citroen 2CV: Cleantech from the 1940s
Obsolete Technology
June 4, 2008
Life Without Airplanes: from London to New York in 3 Days and 12 Hours
Obsolete Technology
May 21, 2008
Is ecotech the new asbestos?
High-tech Problems
May 9, 2008
Mechanical Calculators: Computing Without Electricity
Obsolete Technology
April 24, 2008
The Pinhole Camera: Low-tech Photography
Obsolete Technology
April 18, 2008
Bring Back the Horses
Low-tech Solutions
April 4, 2008
Leave the Algae Alone
High-tech Problems
March 22, 2008
Why bottled water is good for the environment
High-tech Problems
March 16, 2008
Life Before Television
Obsolete Technology
March 3, 2008
The Ugly Side of Solar Panels
High-tech Problems
February 22, 2008
A World Without Trucks: Underground Freight Networks
Obsolete Technology
February 18, 2008
Download, print, fold, paste
Low-tech Solutions
February 13, 2008
The Right to 35 Mobiles
High-tech Problems
February 7, 2008
Faster Internet is Impossible
High-tech Problems
January 25, 2008
The digital oubliette
High-tech Problems
January 21, 2008
Why the electric car has no (wireless) future
High-tech Problems
January 18, 2008
Satellite Navigation in the 18th Century
Obsolete Technology
January 14, 2008
The World's Factory Hall
High-tech Problems
January 11, 2008
Gaming unplugged
Low-tech Solutions
January 9, 2008
Cars on Hot Air
High-tech Problems
January 3, 2008
Information damages the environment
High-tech Problems
December 29, 2007
Heat your House with Car Tyres and Earth
Low-tech Solutions
December 23, 2007
Email in the 18th Century: The Optical Telegraph
Obsolete Technology
May 14, 2007
Second Hand Bits and Bytes
High-tech Problems
April 6, 2007
High speed trains: planes on wheels
High-tech Problems
January 1, 1

## Selected related public links

[
  {
    "text": "Winter is Coming: Build a Solar Powered Foot Stove",
    "href": "https://solar.lowtechmagazine.com/2025/11/winter-is-coming-build-a-solar-powered-foot-stove/"
  },
  {
    "text": "How to Brew Solar Powered Coffee",
    "href": "https://solar.lowtechmagazine.com/2025/11/how-to-brew-solar-powered-coffee/"
  },
  {
    "text": "How to Build a Solar Powered Electric Oven",
    "href": "https://solar.lowtechmagazine.com/2025/10/how-to-build-a-solar-powered-electric-oven/"
  },
  {
    "text": "How to Build a Small Solar Power System",
    "href": "https://solar.lowtechmagazine.com/2023/12/how-to-build-a-small-solar-power-system/"
  },
  {
    "text": "Direct Solar Power: Off-Grid Without Batteries",
    "href": "https://solar.lowtechmagazine.com/2023/08/direct-solar-power-off-grid-without-batteries/"
  },
  {
    "text": "Rebuilding a Solar Powered Website",
    "href": "https://solar.lowtechmagazine.com/2023/06/rebuilding-a-solar-powered-website/"
  },
  {
    "text": "How to Build a Low-tech Solar Panel?",
    "href": "https://solar.lowtechmagazine.com/2021/10/how-to-build-a-low-tech-solar-panel/"
  },
  {
    "text": "Thermoelectric Stoves: Ditch the Solar Panels?",
    "href": "https://solar.lowtechmagazine.com/2020/05/thermoelectric-stoves-ditch-the-solar-panels/"
  },
  {
    "text": "How Sustainable is a Solar Powered Website?",
    "href": "https://solar.lowtechmagazine.com/2020/01/how-sustainable-is-a-solar-powered-website/"
  },
  {
    "text": "The Solar Powered Website in Spanish, French, and Other Languages",
    "href": "https://solar.lowtechmagazine.com/2020/01/the-solar-powered-website-in-spanish-french-and-other-languages/"
  },
  {
    "text": "History and Future of the Compressed Air Economy",
    "href": "https://solar.lowtechmagazine.com/2018/05/history-and-future-of-the-compressed-air-economy/"
  },
  {
    "text": "How (Not) to Run a Modern Society on Solar and Wind Power Alone",
    "href": "https://solar.lowtechmagazine.com/2017/09/how-not-to-run-a-modern-society-on-solar-and-wind-power-alone/"
  },
  {
    "text": "How Sustainable is PV solar power?",
    "href": "https://solar.lowtechmagazine.com/2015/04/how-sustainable-is-pv-solar-power/"
  },
  {
    "text": "The Solar Envelope: How to Heat and Cool Cities without Fossil Fuels",
    "href": "https://solar.lowtechmagazine.com/2012/03/the-solar-envelope-how-to-heat-and-cool-cities-without-fossil-fuels/"
  },
  {
    "text": "The Bright Future of Solar Thermal Powered Factories",
    "href": "https://solar.lowtechmagazine.com/2011/07/the-bright-future-of-solar-thermal-powered-factories/"
  },
  {
    "text": "The Short History of Early Pedal Powered Machines",
    "href": "https://solar.lowtechmagazine.com/2011/05/the-short-history-of-early-pedal-powered-machines/"
  },
  {
    "text": "Wind Powered Factories: History (and Future) of Industrial Windmills",
    "href": "https://solar.lowtechmagazine.com/2009/10/wind-powered-factories-history-and-future-of-industrial-windmills/"
  },
  {
    "text": "The Ugly Side of Solar Panels",
    "href": "https://solar.lowtechmagazine.com/2008/03/the-ugly-side-of-solar-panels/"
  }
]
