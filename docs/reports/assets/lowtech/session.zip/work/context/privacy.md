# Public document capture: privacy

Publisher: Low-tech Magazine
Requested source: https://solar.lowtechmagazine.com/privacy/
Final source: https://solar.lowtechmagazine.com/privacy/
Captured at: 2026-11-06T08:44:54.493Z
HTTP status: 200
Capture method: headless Chromium, rendered main text; no performance measurement.
Limitations: publisher self-report; no independent verification, no internal records. Complete rendered main text within selected page, excluding navigation where main exists.

## Captured source wording

Privacy

This website does not use cookies or advertising services. We collect anonymous data to understand traffic on the server. This information is viewed only by us and is not used to make user profiles.

Low-tech Magazine does not collect any personal data of its website visitors, and consequently we are not required by law to have a privacy policy. Nevertheless, we want to be transparent and open to our visitors.

From the launch of this site in 2018 we have collected web server access logs and processed them on the server with GoAccess. These logs are collected and analyzed to better understand traffic on this this site, find errors and improve functionality. This data is not shared with third parties nor used to do any profiling.

Additionally, since January 2024, we started using Plausible Analytics. Plausible Analytics is a privacy-first web analytics tool. It is built to be compliant with the different privacy regulations, such as GDPR and CCPA. Plausible doesn’t use cookies and doesn’t collect any personal data whatsoever. All data is in aggregate only. See their data policy page.

## Selected related public links

[]
