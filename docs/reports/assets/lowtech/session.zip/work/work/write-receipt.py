import hashlib
import json
import re
from datetime import UTC,datetime
from pathlib import Path
b=Path('.audit-work/diversity/lowtech')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
e=json.loads((b/'editorial.json').read_text());r=json.loads((b/'session/review.json').read_text());m=json.loads((b/'screenshots/manifest.json').read_text())
assert e['reviewSHA256']==sha(b/'session/review.json')
assert len(e['checks'])==30 and len({x['checkId'] for x in e['checks']})==30
assert {x['checkId'] for x in e['checks']}=={x['checkId'] for x in r['rows']}
assert [x['checkId'] for x in e['findings']]==[x['checkId'] for x in r['topFindings']]
for x in m['captures']:assert sha(b/'screenshots'/x['file'])==x['fileSHA256']
md=(b/'work/report-preview.md').read_text(); anchors=set(re.findall(r'\{#([^}]+)\}|id="([^"]+)"',md)); ids={x for pair in anchors for x in pair if x};links=re.findall(r'(?:href="|\]\()#([a-zA-Z0-9_-]+)',md);missing=sorted(set(links)-ids)
# Automatic heading identifiers are assigned by MkDocs at the themed preview stage.
manual_links=[x for x in missing if x.startswith(('evidence-','findings-','measure-'))]
assert not manual_links,manual_links
inputs=['session/review.json','session/scores.json','session/rubric.json','session/checks.json','session/staged.json','session/probes.json','session/context.json','session/packet.json','session/reviews.json','review-tasks/evidence.result.json','review-tasks/guidelines.result.json','review-tasks/claims.result.json','review-tasks/resolutions.json','claims-supplement.json','energy/manifest.json','annual.json']
out={
 'schemaVersion':'sustainability-report-receipt-v1',
 'site':e['site'],'createdAt':datetime.now(UTC).isoformat(),
 'writer':e['writer'],'reviewer':r['reviewer'],
 'reviewSHA256':e['reviewSHA256'],
 'inputSHA256':{name:sha(b/name) for name in inputs},
 'sharedInputSHA256':{'traffic.json':sha(b.parent/'traffic.json')},
 'skillSHA256':{name:sha(Path('.agents/skills/sustainability-report')/name) for name in ['SKILL.md','references/writing.md','references/editorial.schema.json','assets/report-template.md']},
 'outputSHA256':{'editorial.json':sha(b/'editorial.json'),'screenshots/manifest.json':sha(b/'screenshots/manifest.json'),'screenshots/oven-illustration.png':sha(b/'screenshots/oven-illustration.png'),'work/report-preview.md':sha(b/'work/report-preview.md'),'work/annual-preview.json':sha(b/'work/annual-preview.json')},
 'validation':{
  'reviewBinding':'passed','everyCheckExactlyOnce':True,'checkCount':30,'topFindingIdsAndOrderPreserved':True,'judgmentOrPriorityChanges':False,
  'screenshotInspected':True,'screenshotDescription':'Open insulated oven photograph and caption; illustrates dithering at desktop display size without certifying instructional legibility.',
  'screenshotDigestVerified':True,'privateMarkdownRender':'passed using current annual.json, energy manifest and exact traffic source; numerical values unchanged after provenance refresh',
  'internalEvidenceAndMethodAnchors':'passed','themedDesktopAndNarrowPreview':'root publishing coordinator to perform',
  'annualPublishedInputRender':'passed after root regenerated annual provenance with exact audit scope; original attempt retained and scenario values unchanged'
 },
 'illustrationAttempts':{'retainedOutsidePublishBundle':['work/screenshots/manifest.json','work/illustrations/manifest.json'],'reason':'Initial alternative text mentioned nearby content not visible in the inspected viewport; final capture uses a descriptive image-and-caption alternative.'},
 'reproductionCommand':['uv','run','python','audit/render_review.py','--session',str(b/'session'),'--artifact-prefix','../session','--editorial',str(b/'editorial.json'),'--screenshots',str(b/'screenshots/manifest.json'),'--image-prefix','../screenshots','--energy',str(b/'energy/manifest.json'),'--annual',str(b/'annual.json'),'--traffic',str(b.parent/'traffic.json'),'--supplement-prefix','..','--output',str(b/'work/report-preview.md')],
 'limitations':['Report wording does not change frozen judgments or priorities.','Historical public governance, service-necessity and goal records cover the declared 2018–2020 decisions; current operational governance and independently verified hosting remain unresolved.','Client energy covers two initial-load page scenarios with three repetitions each using a resource-counter model, not direct electricity metering or full reading sessions.','Annual SWDM and client energy projections use a rank-derived traffic scenario and overlapping scopes; they must not be added.']
}
(b/'report-receipt.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print('Receipt written; all 30 check IDs, both finding IDs/order, screenshot digest, and named internal anchors verified.')
