import asyncio,json
from pathlib import Path
from datetime import datetime,UTC
from playwright.async_api import async_playwright
async def main():
 root=Path('.audit-work/diversity/tate/captures')
 async with async_playwright() as p:
  b=await p.chromium.launch(headless=True);c=await b.new_context(viewport={'width':1440,'height':1000});page=await c.new_page();steps=[]
  try:
   await page.goto('https://www.tate.org.uk/',wait_until='domcontentloaded',timeout=30000);await page.wait_for_timeout(1500)
   for selector in ['a[href="/visit/tate-modern"][aria-label="Tate Modern"]','a[href="#accessibility"]']:
    count=await page.locator(selector).count();await page.locator(selector).click(timeout=7000);await page.wait_for_timeout(800)
    steps.append({'selector':selector,'count':count,'urlAfter':page.url,'h1':await page.locator('h1').all_text_contents()})
   d={'capturedAt':datetime.now(UTC).isoformat(),'url':page.url,'steps':steps,'h1':await page.locator('h1').all_text_contents(),'accessibilityVisible':await page.locator('#accessibility').is_visible(),'accessibilityText':await page.locator('#accessibility').inner_text(),'body':(await page.locator('body').inner_text())[:34000],'inputs':await page.locator('input').evaluate_all('(xs)=>xs.map(x=>({name:x.name,type:x.type,id:x.id,required:x.required,placeholder:x.placeholder}))')}
   (root/'journey.json').write_text(json.dumps(d,indent=2));print('JOURNEY',d['url'],d['accessibilityVisible'],d['accessibilityText'][:500],flush=True)
   for name,url in [('green','https://www.tate.org.uk/about-us/digital/green-website'),('cookie-browser','https://www.tate.org.uk/about-us/policies-and-procedures/website-terms-use/cookie-policy')]:
    response=await page.goto(url,wait_until='domcontentloaded',timeout=30000);await page.wait_for_timeout(2000)
    body=await page.locator('body').inner_text();main=page.locator('main');d={'url':page.url,'status':response.status,'capturedAt':datetime.now(UTC).isoformat(),'title':await page.title(),'text':await main.inner_text() if await main.count() else body,'buttons':await page.locator('button').evaluate_all('(xs)=>xs.map(x=>({id:x.id,text:x.innerText,aria:x.getAttribute("aria-label")}))'),'consentMatches':await page.locator('[id*="onetrust"],[id*="cookie"],button:has-text("Accept"),button:has-text("Reject")').count()}
    (root/f'{name}.json').write_text(json.dumps(d,indent=2));print(name,d['status'],d['title'],d['text'][:10000],d['buttons'],flush=True)
  except Exception as e:print(type(e).__name__,str(e),flush=True)
  await c.close();await b.close()
asyncio.run(main())
