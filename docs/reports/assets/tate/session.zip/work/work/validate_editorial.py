import hashlib
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
import sys

ROOT=Path.cwd()
sys.path.insert(0,str(ROOT))
from audit.render_review import validate_editorial

schema=json.loads((ROOT/'.agents/skills/sustainability-report/references/editorial.schema.json').read_text())
def validate_schema(value, spec, at='$'):
 types={'object':dict,'array':list,'string':str}
 if 'type' in spec: assert isinstance(value,types[spec['type']]), at
 if 'enum' in spec: assert value in spec['enum'], at
 if isinstance(value,dict):
  assert set(spec.get('required',[]))<=value.keys(), at
  if spec.get('additionalProperties') is False: assert value.keys()<=spec['properties'].keys(),at
  for k,v in value.items():
   if k in spec.get('properties',{}):validate_schema(v,spec['properties'][k],f'{at}.{k}')
 if isinstance(value,list):
  for i,v in enumerate(value):validate_schema(v,spec['items'],f'{at}[{i}]')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['tate','w3c']:
 p=ROOT/'.audit-work/diversity'/name
 raw=(p/'session/review.json').read_bytes();review=json.loads(raw)
 editorial=json.loads((p/'editorial.json').read_text())
 validate_schema(editorial,schema)
 validate_editorial(editorial,review,hashlib.sha256(raw).hexdigest())
 preview=(p/'work/report-preview.md').read_text()
 assert editorial['overview'] in preview
 assert all(f['summary'] in preview for f in editorial['findings'])
 anchors=set(re.findall(r'\{#([^}]+)\}',preview))|set(re.findall(r'id="([^"]+)"',preview))
 targets=set(re.findall(r'\]\(#([^)]+)\)',preview))|set(re.findall(r'href="#([^"]+)"',preview))
 assert targets<=anchors, sorted(targets-anchors)
 assert len(re.findall(r'<h4 id="evidence-',preview))==len(review['rows'])
 shutil.copyfile(p/'editorial.json',p/'work/editorial.json')
 inputs=[p/'session'/f for f in ['review.json','scores.json','score-receipt.json','packet.json','plan.json','staged.json','probes.json','context.json','checks.json','rubric.json']]
 inputs += sorted((p/'review-tasks').glob('*.result.json')) + [p/'review-tasks/resolutions.json',p/'energy/manifest.json',p/'annual.json',p/'claims-supplement.json',ROOT/'.audit-work/diversity/traffic.json']
 inputs += [ROOT/f for f in ['.agents/skills/sustainability-report/SKILL.md','.agents/skills/sustainability-report/references/writing.md','.agents/skills/sustainability-report/references/editorial.schema.json','.agents/skills/sustainability-report/assets/report-template.md','audit/render_review.py','audit/report_details.py']]
 command=['uv','run','--locked','--script','audit/cli.py','tool','render_review','--session',f'.audit-work/diversity/{name}/session','--artifact-prefix','../session','--editorial',f'.audit-work/diversity/{name}/editorial.json','--energy',f'.audit-work/diversity/{name}/energy/manifest.json','--annual',f'.audit-work/diversity/{name}/annual.json','--traffic','.audit-work/diversity/traffic.json','--supplement-prefix','..','--output',f'.audit-work/diversity/{name}/work/report-preview.md']
 receipt={
  'schemaVersion':'report-editorial-receipt-v1','site':review['site'],'createdAt':datetime.now(timezone.utc).isoformat(),
  'writer':editorial['writer'],'reviewer':review['reviewer'],
  'scope':'Editorial pass over the scored frozen audit and separate annual/energy/claims supplements; no audit judgments, priorities, evidence or scores changed.',
  'inputSHA256':{str(f.relative_to(ROOT)):sha(f) for f in inputs},
  'outputs':{str(f.relative_to(ROOT)):sha(f) for f in [p/'editorial.json',p/'work/report-preview.md']},
  'commands':[{'argv':command,'exitCode':0}],
  'validation':{'editorialSchema':'passed','reviewHashBinding':'passed','everyCheckExactlyOnce':len(editorial['checks']),'topFindingIdsAndOrder':'preserved','markdownInternalAnchors':'passed','readablePriorityAndMeasurementSections':'inspected'},
  'screenshots':{'included':False,'reason':'The priorities concern hidden resource delivery, semantic structure and uninspected print output; a page screenshot would not substantiate those findings.'},
  'preview':{'kind':'Private Markdown render','themedDesktopAndNarrowPreview':'Delegated to publishing coordinator','supplementDownloadLinks':'Publishing coordinator supplies final artifact paths.'}
 }
 (p/'report-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
 print(name, 'validated',len(editorial['checks']),'checks;',len(editorial['findings']),'priorities;',len(targets),'internal targets')
