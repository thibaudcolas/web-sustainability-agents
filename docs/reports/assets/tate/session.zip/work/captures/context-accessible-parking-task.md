# accessible-parking-task

Source: https://www.tate.org.uk/
Captured at: 2026-11-06T08:45:06.828643+00:00
Scope: Anonymous English readers using desktop Chromium with pointer input and JavaScript, 1440 by 1000 CSS pixels: start at https://www.tate.org.uk/, follow the Tate Modern gallery card, open Accessibility, and read the accessible-parking location plus advance-booking phone/email instructions. Completion is obtaining public information; no parking booking, ticket purchase, account, contact or form submission. Keyboard-only, assistive-technology, constrained-device and physical-gallery accessibility are outside this assessment scope.
Limitations: Agent desktop pointer walkthrough, not representative-user testing or proof of physical access. No booking was attempted.

{
  "capturedAt": "2026-11-06T08:45:06.828643+00:00",
  "url": "https://www.tate.org.uk/visit/tate-modern",
  "steps": [
    {
      "selector": "a[href=\"/visit/tate-modern\"][aria-label=\"Tate Modern\"]",
      "count": 1,
      "urlAfter": "https://www.tate.org.uk/visit/tate-modern",
      "h1": [
        "\n                        \n                        Tate Modern\n                        \n                    "
      ]
    },
    {
      "selector": "a[href=\"#accessibility\"]",
      "count": 1,
      "urlAfter": "https://www.tate.org.uk/visit/tate-modern",
      "h1": [
        "\n                        \n                        Tate Modern\n                        \n                    "
      ]
    }
  ],
  "h1": [
    "\n                        \n                        Tate Modern\n                        \n                    "
  ],
  "accessibilityVisible": true,
  "accessibilityText": "ACCESSIBILITY",
  "body": "Skip navigation\nMAIN MENU\nWHAT'S ON\nVISIT\nART\nLEARN\nSHOP\nBECOME A MEMBER\nFREE\nTATE MODERN\n\nFree admission\n\nOPENING TIMES\n\nSunday to Thursday 10.00\u201318.00\n\nFriday to Saturday 10.00\u201321.00\n\nBankside, London SE1 9TG\nWhat's on\n \nPlan your free visit\n \nIn Tate Modern\n \nGetting here\n \nAdmission information\n \nVisiting guides\n \nAccessibility\n\nHenri Matisse\nThe Snail (1953)\nTate\n\nExplore modern and contemporary art from around the world\n\nSee some of the world\u2019s most exciting modern and contemporary art at Tate Modern. Enjoy innovative works that have shaped art as we know it. Our gallery is free to visit. On display are paintings, sculptures and large-scale installations from artists around the world including Pablo Picasso, Yayoi Kusama and Henri Matisse. Explore the iconic Turbine Hall alongside our underground Tanks, a striking space dedicated to live performances and video.\n\nMembers enjoy unlimited free entry to exhibitions with no need to book.\n\nDownload the Tate Modern map [PDF, 1240 Kb]\nWHAT'S ON\nEXHIBITIONS\nFrida: The Making of an Icon\n\nStep into the life and legacy of Frida Kahlo: revolutionary artist and global icon\n\nTATE MODERN\nUNTIL 3 JAN 2027\nFREE FOR MEMBERS\nEXHIBITIONS\nJulio Le Parc: Light. Colour. Action.\n\nDiscover seven decades of joyful works by Argentinian artist Julio Le Parc, which turns visitors into active participants\n\nTATE MODERN\nUNTIL 3 MAY 2027\nFREE FOR MEMBERS\nEXHIBITIONS\nAna Mendieta\n\nExperience the powerful work of Ana Mendieta, whose legacy changed the course of contemporary art\n\nTATE MODERN\nUNTIL 17 JAN 2027\nFREE FOR MEMBERS\nAll exhibitions and events at Tate Modern\nPLAN YOUR FREE VISIT\nRight\nREAD\nSee great art for free at Tate Modern\n\nOur top 10 collection highlights represent a mix of new and favourite artworks not to miss\n\nREAD\n5 free things to do at Tate Modern\n\nGreat art, a world-class view, activities for families and more \u2013 for free\n\nIn the Studio\n\nInvestigate the processes artists use to make artworks, and how our responses are integral to the piece\n\nFREE\nPerformer and Participant\n\nDiscover how artists working between the 1960s and the 1990s opened up new spaces for participation\n\nFREE\nARTIST ROOMS: Francesca Woodman\n\nThese works combine photography and performance to explore hidden parts of the self\n\nFREE\nMaterials and Objects\n\nDiscover artists from Tate's collection who have embraced new and unusual materials and methods\n\nFREE\nMedia Networks\n\nSee how artists in Tate\u2019s collection have responded to the impact of mass media\n\nFREE\nTOURS\nTALKS AND DISCUSSION\nTate Modern Free Guided Tours\n\nLearn about the art in Tate Modern with a guided tour around part of the gallery\n\nTATE MODERN\nTOURS RUN MOST DAYS\nFREE\nExplore all free displays\nTATE MEMBERS\n\nEnjoy unlimited free entry to every exhibition at all our galleries\n\nJoin today\nIN TATE MODERN\nTATE MODERN RESTAURANT & BAR\n\nOur Restaurant & Bar sits at the top of Tate Modern with panoramic views across the Thames of St Paul\u2019s \u2026\n\nCORNER\n\nCafe, Bar, Venue\n\nTERRACE SHOP\n\nDiscover a range of artist books, designer collaborations, jewellery and prints\n\nTATE DRAW\n\nSee your drawings come to life using our digital sketch pads at Tate Modern\n\nGRANVILLE-GROSSMAN MEMBERS BAR\n\nPop in to our lively bar and enjoy a spectacular view of London\n\nLEVEL 1 MEMBERS BAR\n\nRelax, recharge, and refuel in our exclusive Members Bar, open daily\n\nAll food and drink venues\nGETTING HERE\nADDRESS\nTate Modern\nBankside\nLondon SE1 9TG\nDIRECTIONS\n WALK\n CYCLE\n RIDE\n DRIVE\nBY BIKE\nBY BUS\nBY TRAIN\nBY TUBE\nBY BOAT\nBY TAXI\nBY CAR\nBY COACH\nADMISSION INFORMATION\nENTRY DETAILS\n\nEntry to the collection is free for everyone. Booking is recommended for exhibitions.\n\nExhibition entry\nMembers and Supporters enjoy free exhibition entry \u2013 no need to book, just turn up with your card\nVisitors with a disability pay a concessionary rate, and entrance for companions is free\nVisitors aged 16\u201325 can join Tate Collective to access \u00a35 exhibition tickets\nUp to four children aged 11 and under go free per parent or guardian\n\u00a35 family child tickets are available for children aged 12\u201318 years\n\nFor more information see our Booking and Ticketing FAQs.\n\nEntrance\n\nEntry is via the Turbine Hall ramp or via the Blavatnik Building.\n\nBag policy\n\nBags are checked on arrival so please allow extra time for security checks.\n\nWe reserve the right not to allow any bag, parcel, or other item to be brought into the gallery.\n\nPotentially dangerous objects are also not permitted.\n\nBags and items larger than cabin bag size (55cm x 40cm x 20cm) are not permitted in the building.\n\nWheely luggage and cabin bags are not permitted in ticketed exhibitions.\n\nThere is a left luggage facility available at London Bridge stations.\n\nStoring your personal items\n\nLockers are available to rent on L0 of the Blavatnik Building. The lockers do not accept cash.\n\nDimensions and prices:\n\nStandard (\u00a34, 36cm x 30cm x 43cm)\nLarge (\u00a36, 44cm x 36cm x 42cm)\nJumbo (\u00a38, 58cm x 44cm x 66cm)\n\nLockers are free of charge for Tate Members.\n\nPlease note that the cloakroom in the Natalie Bell Building on Level 0 has now closed.\n\nSkateboards, scooters, and folding bike policy\n\nElectric skateboards, scooters and folding bikes are not permitted in the building, nor are the batteries removed from these e-vehicles. Non-electric skateboards, scooters and folding bikes are permitted, but must be stored in the cloakroom at Tate Britain or in the paid locker facilities at Tate Modern (lockers are free of charge for Tate Members). Please note that cloakroom and locker capacity is limited, and during busy periods we may not be able to accept these items. We advise you check the dimensions of your items in advance to ensure they fit within our locker size limits.\n\nSecurity\n\nWe take security very seriously and work closely with Police Project Servator teams. You can read more about our approach to safety and rules for the gallery.\n\nOPENING TIMES\n\nSunday to Thursday 10.00\u201318.00\n\nFriday to Saturday 10.00\u201321.00\n\nLast entry 30 minutes before closing time\n\nVISITING GUIDES\nRight\nREAD\nTate Modern visual story\n\nA step-by-step visual and written guide to help you plan your visit\n\nREAD\nVisit Tate Modern with your family\n\nPlan your visit to Tate Modern with our family visiting tips and FAQs\n\nREAD\nSchool visits to Tate Modern\n\nExplore art and ideas to take ownership of the gallery\n\nREAD\nA guide to slow looking\n\nBe amazed by the discoveries you can make when you look for longer at art\n\nREAD\nVisiting tips for social care professionals\n\nInformation and resources to help social care professionals plan a visit to Tate\n\nACCESSIBILITY\nAccessible car parking\nEntrance\nWheelchair and mobility scooter provision\nFacilities at Tate Modern\nAssistance dogs\nAutism\nBlind and visually impaired visitors\nDeaf and hard of hearing visitors\nDyslexic visitors\nEpilepsy and Seizures\nCommunication cards\nAccess events\nWebsite\nContact Us\nAccessible car parking\n\nThere are twelve parking spaces for disabled visitors, accessed via Park Street. Please book these spaces at least 24 hours in advance.\n\nTo book accessible parking:\nEmail ticketing@tate.org.uk\nCall +44 (0)20 7887 8888 \u2013 option 1 (daily 10.00\u201317.00)\nOur phone line supports the use of speech recognition apps\n\nYour name, contact details, vehicle registration number, date and time of visit are required to make the booking for an accessible parking space\n\nOnce you have parked, enter via the South Entrance of the Blavatnik Building across the level terrace, approximately 30 \u2013 60 metres from the parking spaces.\n\nTwo RADAR Key operated lifts link the South Entrance on Level 1 and the Ticket desks in the Turbine Hall. RADAR keys are available from staff at the South Entrance on Level 1 and ticket desks on Level 0.\n\nIf you have booked a mobility scooter or wheelchair, these can also be collected from the South Entrance.\n\nABOUT\n\nAbout Tate\n\nAbout our collection\n\nGovernance\n\nPress\n\nJobs\n\nImage licensing\n\nTerms and copyright\n\nJOIN AND SUPPORT\n\nMy account\n\nMembers\n\nTate Collective\n\nPatrons\n\nCorporate\n\nDonate\n\nSTAY IN TOUCH\n\nExhibitions, events, offers and news from across Tate's galleries \u2013 straight to your inbox:\n\nEnter your email address\n\nSign up\n\nWe'll look after your data. Read our privacy policy.\nThis site is protected by reCAPTCHA.\n\nOUR GALLERIES\n\nTate Modern\n\nTate Britain\n\nTate Liverpool\n\nTate St Ives\n\n\u00a9 The Board of Trustees of the\nTate Gallery, 2026\n\n \n \n \n|\n\nAccessibility\n\n \n\nPrivacy\n\n \n\nCookies\n\n \n\nContact\n\nBack to top",
  "inputs": [
    {
      "name": "q",
      "type": "search",
      "id": "search-input",
      "required": false,
      "placeholder": "What are you looking for?"
    },
    {
      "name": "action_step",
      "type": "hidden",
      "id": "",
      "required": false,
      "placeholder": ""
    },
    {
      "name": "source",
      "type": "hidden",
      "id": "",
      "required": false,
      "placeholder": ""
    },
    {
      "name": "email",
      "type": "email",
      "id": "email",
      "required": true,
      "placeholder": "Enter your email address"
    },
    {
      "name": "g-recaptcha-token-footer",
      "type": "hidden",
      "id": "g-recaptcha-token-footer",
      "required": false,
      "placeholder": ""
    }
  ]
}
