# digital-team

Source: https://www.tate.org.uk/about-us/digital
Captured at: 2026-11-06T08:43:02.149608+00:00
Scope: Digital | Tate
Limitations: Attributed public self-report only. No independent emissions methodology, baseline comparability, meeting minutes or documented review-to-action chain verified. Browser navigation to green-website timed out once while separate HTTP retrieval returned intended page HTTP200.

Digital Using technology to enrich people's everyday lives through art Accessibility Sustainability Contact us Sir Eduardo Paolozzi C. Left: Le Robot ‘Robert’ Voulait Aller à New York Mais le Passager est Trop Lourd: TWA Plane - Steps - Cap 14 Persons with Two Stewardesses. Right: Wonder Toy, Robert the Robot (1971) Tate © The Eduardo Paolozzi Foundation Tate Digital champions art and artists by creating rich content experiences to showcase our collection, galleries and exhibitions. We want to make art accessible to everyone. We balance the needs of visitors who come to the galleries with those who want to learn, participate and engage with art and artists on digital platforms. The Digital team promotes digital growth and engagement with an emphasis on improved accessibility and user journeys, reaching new audiences, while continuing to develop high quality digital experiences for Tate’s loyal fans. The team works with user-centred practices (including quantitative and qualitative research) to ensure that development done serves evidenced user needs. Our website is home to an extensive digitised art and archive collection, and highly acclaimed digital strands including Tate Kids , Tate Collective , and Tate’s online learning resources. We develop, renew and extend our digital properties to make the best use of new technologies, and make sure they are accessible to broad audiences. Our ‘audience first’ content strategy helps us to realise our ambition to produce quality content that builds scale, particularly for non-specialist audiences. This includes understanding the impact of our content, changing the types of content that we make and increasing community engagement. We continue to develop engaging and innovative in-gallery experiences, including sponsored projects. Working closely with our colleagues in curatorial, learning and visitor experiences the digital team continues to build on previous successes to create rewarding experiences before, during and after a visitation. We are significantly improving and growing eCommerce by integrating it into visitor journeys and improving the checkout experience. View the archive of our website Accessibility To report any accessibility issues please contact information@tate.org.uk with 'Web Accessibility' as the subject line. Read our accessibility statement Sustainability Our Digital Green Team meets regularly to plan ways to reduce the carbon footprint of our website. Learn more about creating a greener website Contact us If you have any comments about the Tate website, please email information@tate.org.uk Awards 2012 Lovie Awards Art: gold ( Art & Artists ) Games: gold (Wondermind, Tate Kids) Best Use of Interactive Video: silver (Wondermind, Tate Kids) Webby Awards Official Honoree: Best Use of Interactive Video: silver (Wondermind, Tate Kids) Official Honoree: Games (Wondermind, Tate Kids) Museums and the Web Best Education Website (Honorable Mention) (Wondermind, Tate Kids) SXSW Finalist – Educational Resource (Wondermind, Tate Kids) Interactive Media Awards Best in Class, Kids (Wondermind, Tate Kids) 2011 Museums and the Web Best Social Media Website (Ai Weiwei: One-to-One with the Artist) Interactive Media Awards Best in Class, Kids (AirBrush, Tate Kids) Lovie Awards Shortlisted, Youth (AirBrush, Tate Kids) NHK Japan Prize Shortlisted, Kids (AirBrush, Tate Kids) 2010 Webby Awards Best Art Website (The Unilever Series 2009: Miroslaw Balka, How It Is) Children’s BAFTAs Nomination: Best Interactive (The Secret Dancer, Tate Kids) Interactive Media Awards Outstanding Achievement, Kids ( Tate Kids ) 2009 Webby Awards Best Youth Website ( Tate Kids ) Museums and the Web Best Education Website ( Tate Kids ) Children’s BAFTAs Nomination: Best Animation (Art Sparks, Tate Kids) Nomination: Best Learning Primary ( Tate Kids ) 2008 BIMA Awards Best Blog (The Great Tate Mod Blog) 2007 IVCA Awards Web TV category, Silver award (BT Series) The Webby Awards Net Art category, Webby Award Winner ( The Dumpster ) 2006 Jodi Awards (iMap) Hollis Sponsorship Award General arts category CIPR Awards Website category 2005 Hollis Sponsorship Award Sponsorship Continuity United Nations World Summit Awards Interactive Media 2004 IPRA Golden World Award for Public Relations Excellence Arts Museums and the Web Best Research Site Jodi Mattes Commended: Access Award (iMap) Bilbao Cibeart Prize Best Net Art ( agoraXchange ) 2003 Bafta Interactive Best Online Factual Hollis Sponsorship Award Best use of Public Relations in a Sponsorship Campaign 2002 Bafta Interactive Accessibility (iMap) London Tourism Award Best Tourism Website (First ever) Social Media Directory Twitter Tate Tate Liverpool Tate St Ives Tate Kids Tate Collective ARTIST ROOMS Tate Etc. Tate Publishing Tate Research Tate Teachers Facebook Tate Tate Liverpool Tate St Ives Tate Members Tate Collective YouTube Tate Tate Kids Pinterest Tate Instagram Tate Tate Liverpool Tate Collective Tate Exchange Tate Eats Tate St Ives Tate Shops TikTok Tate LinkedIn Tate

Discovered source links:
[
  {
    "text": "Accessibility",
    "href": "#none1"
  },
  {
    "text": "Sustainability",
    "href": "#sustainability"
  },
  {
    "text": "Contact us",
    "href": "#none2"
  },
  {
    "text": "C. Left: Le Robot \u2018Robert\u2019 Voulait Aller \u00e0 New York Mais le Passager est Trop Lourd: TWA Plane - Steps - Cap 14 Persons with Two Stewardesses. Right: Wonder Toy, Robert the Robot",
    "href": "https://www.tate.org.uk/art/artworks/paolozzi-c-left-le-robot-robert-voulait-aller-a-new-york-mais-le-passager-est-trop-lourd-p03053"
  },
  {
    "text": "\u00a9 The Eduardo Paolozzi Foundation",
    "href": "/about-us/policies-and-procedures/website-terms-use"
  },
  {
    "text": "Tate Kids",
    "href": "https://www.tate.org.uk/kids"
  },
  {
    "text": "Tate Collective",
    "href": "https://www.tate.org.uk/tate-collective"
  },
  {
    "text": "View the archive of our website",
    "href": "http://webarchive.nationalarchives.gov.uk/*/http://www.tate.org.uk/"
  },
  {
    "text": "information@tate.org.uk",
    "href": "mailto:information@tate.org.uk"
  },
  {
    "text": "Read our accessibility statement",
    "href": "/about-us/accessibility-statement"
  },
  {
    "text": "Learn more about creating a greener website",
    "href": "/about-us/digital/green-website"
  },
  {
    "text": "information@tate.org.uk",
    "href": "mailto:information@tate.org.uk"
  },
  {
    "text": "Art & Artists",
    "href": "https://www.tate.org.uk/art"
  },
  {
    "text": "Tate Kids",
    "href": "http://kids.tate.org.uk/"
  },
  {
    "text": "Tate Kids",
    "href": "http://kids.tate.org.uk/"
  },
  {
    "text": "Tate Kids",
    "href": "http://kids.tate.org.uk/"
  },
  {
    "text": "Tate Kids",
    "href": "http://kids.tate.org.uk/"
  },
  {
    "text": "The Dumpster",
    "href": "http://www2.tate.org.uk/intermediaart/entry15385.shtm"
  },
  {
    "text": "agoraXchange",
    "href": "http://www2.tate.org.uk/intermediaart/entry15278.shtm"
  },
  {
    "text": "Tate",
    "href": "http://twitter.com/tate"
  },
  {
    "text": "Tate\u00a0Liverpool",
    "href": "http://twitter.com/tateliverpool"
  },
  {
    "text": "Tate\u00a0St\u00a0Ives",
    "href": "http://twitter.com/Tate_StIves"
  },
  {
    "text": "Tate\u00a0Kids",
    "href": "http://twitter.com/tate_kids"
  },
  {
    "text": "Tate\u00a0Collective",
    "href": "http://twitter.com/TateCollective"
  },
  {
    "text": "ARTIST\u00a0ROOMS",
    "href": "http://twitter.com/ARTISTROOMS"
  },
  {
    "text": "Tate\u00a0Etc.",
    "href": "http://twitter.com/TATEETCmag"
  },
  {
    "text": "Tate\u00a0Publishing",
    "href": "https://twitter.com/tate_publishing"
  },
  {
    "text": "Tate\u00a0Research",
    "href": "https://twitter.com/tateresearch"
  },
  {
    "text": "Tate\u00a0Teachers",
    "href": "https://twitter.com/tateteachers"
  },
  {
    "text": "Tate",
    "href": "http://www.facebook.com/tategallery"
  },
  {
    "text": "Tate\u00a0Liverpool",
    "href": "http://www.facebook.com/tateliverpool"
  },
  {
    "text": "Tate\u00a0St\u00a0Ives",
    "href": "http://www.facebook.com/stivestate"
  },
  {
    "text": "Tate\u00a0Members",
    "href": "http://www.facebook.com/pages/Tate-Members/6202517957"
  },
  {
    "text": "Tate\u00a0Collective",
    "href": "https://www.facebook.com/tatecollective"
  },
  {
    "text": "Tate",
    "href": "https://www.youtube.com/user/tate?ob=0&feature=results_main"
  },
  {
    "text": "Tate\u00a0Kids",
    "href": "https://www.youtube.com/channel/UCYvsK26rzlH5F_s1BmIwQbw"
  },
  {
    "text": "Tate",
    "href": "http://pinterest.com/tategallery/"
  },
  {
    "text": "Tate",
    "href": "http://instagram.com/tate"
  },
  {
    "text": "Tate\u00a0Liverpool",
    "href": "https://www.instagram.com/tateliverpool/"
  },
  {
    "text": "Tate\u00a0Collective",
    "href": "http://instagram.com/tatecollective"
  },
  {
    "text": "Tate\u00a0Exchange",
    "href": "https://www.instagram.com/tateexchange/"
  },
  {
    "text": "Tate\u00a0Eats",
    "href": "https://www.instagram.com/tateeats/"
  },
  {
    "text": "Tate\u00a0St\u00a0Ives",
    "href": "https://www.instagram.com/tatestives/?hl=en"
  },
  {
    "text": "Tate\u00a0Shops",
    "href": "https://www.instagram.com/tateshops/"
  },
  {
    "text": "Tate",
    "href": "https://www.tiktok.com/@tate?lang=en"
  },
  {
    "text": "Tate",
    "href": "https://uk.linkedin.com/company/tate"
  }
]
