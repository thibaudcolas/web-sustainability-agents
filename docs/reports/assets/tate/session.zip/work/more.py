import requests,json
from bs4 import BeautifulSoup
from pathlib import Path
from datetime import datetime,UTC
jobs={'tate':{'digital':'/about-us/digital','priorities':'/about-us/our-priorities','reports':'/about-us/tate-reports','privacy':'/about-us/policies-and-procedures/tate-privacy-policy','contact':'/about-us/contact-us','exhibition':'/whats-on/tate-modern/julio-le-parc'},'nhs':{'walking':'/live-well/exercise/walking-for-health/','videos':'/live-well/exercise/strength-and-flex-exercise-plan-how-to-videos/','cookie-details':'/our-policies/choose-your-cookie-settings/details-about-cookies-on-the-nhs-website/','privacy':'/our-policies/privacy-policy/'}}
for site,docs in jobs.items():
 for name,path in docs.items():
  try:
   r=requests.get('https://www.'+('tate.org.uk' if site=='tate' else 'nhs.uk')+path,timeout=20);s=BeautifulSoup(r.text,'html.parser');[x.decompose() for x in s(['script','style','svg'])]
   main=s.select_one('main') or s.select_one('#content') or s
   d={'url':r.url,'status':r.status_code,'capturedAt':datetime.now(UTC).isoformat(),'title':s.title.get_text() if s.title else '', 'text':main.get_text(' ',strip=True),'links':[{'text':a.get_text(' ',strip=True),'href':a['href']} for a in main.find_all('a',href=True)]}
   Path(f'.audit-work/diversity/{site}/captures/{name}.json').write_text(json.dumps(d,indent=2))
   print(site,name,r.status_code,d['title'])
   if name in ['digital','priorities','reports']:print(d['text'][:12000])
  except Exception as e:print(site,name,type(e).__name__,str(e))
