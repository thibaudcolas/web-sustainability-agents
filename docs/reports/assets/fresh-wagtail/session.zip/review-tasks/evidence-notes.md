# Fresh wagtail quantitative evidence notes

Frozen packet: `e18c88928aba9a129342a6e2de378fab5301a4abe4f82d75054ce725737579fc`. Fresh Wagtail.org evidence only. No scores or guideline outcomes are assigned. Decimal kB = 1,000 bytes; MB = 1,000,000 bytes.

## Measured scope and limits

Seven pages, two independent cold visits per page (reject/accept), three cumulative phases per visit: 14 visits and 42 phases. All phases are partial. Each initial capture has unresolved bytes for the Plausible 404 script and a GA collection response (status 204 with ERR_ABORTED). Both article initial captures additionally have two aborted YouTube XHRs with no status; all six article phases have the explicit child-frame traffic gap. Other pages have no explicit frame gap, but still have unresolved resource bytes. A finished aborted request with receivedBytes=null is unresolved, not measured zero. A tiny response Content-Length does not fill the unknown CDP transfer amount.

Every stored rating is `not_calculated`: no eligible complete-input Digital Carbon Rating or full-input SWDM estimate. Partial accounted bytes remain useful for ranking captured resource opportunities. Avoid turning collector/resource problems into the headline site defect or requiring a repaired Plausible configuration before recommending useful work.

Protocol: desktop 1280 × 800 CSS px, DPR 1, fresh anonymous context per branch, three-second observation, CDP received network bytes including reported overhead. Main CDP target; service workers blocked, child-frame traffic incomplete. Supplementary probes are qualitative and are not extra headline byte samples.

## Phase totals

Every number below is an incomplete observed accounted total. After-choice totals equal initial on all 14 visits: actual Opt out / Opt in clicks complete, but add 0 accounted bytes and 0 requests. The scroll column is cumulative; delta is additional accounted traffic. Initial is before either cookie decision, so branch differences are capture variability, not consent effects.

| Page and branch | Initial bytes | Initial kB | Initial requests | After-choice kB | After-scroll kB | Scroll delta kB | Initial unresolved | Final unresolved |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| home-reject | 944,428 | 944.428 | 36 | 944.428 | 1107.822 | 163.394 | 2 | 3 |
| home-accept | 945,635 | 945.635 | 36 | 945.635 | 1109.026 | 163.391 | 2 | 3 |
| features-reject | 639,013 | 639.013 | 18 | 639.013 | 719.621 | 80.608 | 2 | 3 |
| features-accept | 638,031 | 638.031 | 18 | 638.031 | 718.489 | 80.458 | 2 | 3 |
| release-article-reject | 2,025,844 | 2025.844 | 60 | 2025.844 | 2028.486 | 2.642 | 4 | 5 |
| release-article-accept | 2,031,558 | 2031.558 | 60 | 2031.558 | 2034.194 | 2.636 | 4 | 5 |
| search-reject | 465,514 | 465.514 | 15 | 465.514 | 465.514 | 0.000 | 2 | 2 |
| search-accept | 464,664 | 464.664 | 15 | 464.664 | 464.664 | 0.000 | 2 | 2 |
| sustainability-reject | 592,293 | 592.293 | 20 | 592.293 | 635.238 | 42.945 | 2 | 3 |
| sustainability-accept | 590,304 | 590.304 | 20 | 590.304 | 633.254 | 42.950 | 2 | 3 |
| privacy-reject | 465,046 | 465.046 | 15 | 465.046 | 465.046 | 0.000 | 2 | 2 |
| privacy-accept | 464,450 | 464.450 | 15 | 464.450 | 464.450 | 0.000 | 2 | 2 |
| contact-reject | 465,749 | 465.749 | 16 | 465.749 | 465.749 | 0.000 | 2 | 2 |
| contact-accept | 464,919 | 464.919 | 16 | 464.919 | 464.919 | 0.000 | 2 | 2 |

Evidence IDs are `staged.json:runs:0` through `staged.json:runs:13` in this order. Do not sum cumulative phases, calculate cookie savings from initial branch differences, average branches as traffic mix, or imply a full-site load measurement. All 14 actual clicks complete; cookie storage and behavior on a later independent visit are not measured.

## Main resource candidates

The release article has 2.026 MB and 2.032 MB of initial accounted traffic for reject/accept, with 60 requests each, before playback. Reject initial host accounting:

| Scope | Accounted kB |
| --- | ---: |
| www.youtube.com | 1156.528 |
| i.ytimg.com | 104.223 |
| fonts.gstatic.com | 40.678 |
| www.google.com | 25.029 |
| googleads.g.doubleclick.net | 0.899 |
| static.doubleclick.net | 0.494 |
| jnn-pa.googleapis.com | 0.457 |

These related player hosts sum to 1,328,308 bytes (1.328 MB), 65.6% of the incomplete initial reject total. This is captured related traffic, not a complete iframe footprint or a verified saving. The two direct YouTube Document requests are 73.508 and 60.070 kB; repeated cached zero-byte assets follow. No player activation/stream playback was tested, so a facade requires an accessible activation test and task alternative before any claimed saving. The main-document media array omits this iframe and cannot establish absence of media.

Homepage native video is paused, has controls, no autoplay, and preload=none. It sits at y=917px and causes no video transfer in the captured network. Credit this distinct behavior; it is not the article embed. Its poster is about 6.570 kB in reject. Playback remains untested.

Homepage's large screenshot is already WebP, natural width 2234px, rendered 1280px desktop/360px narrow, no srcset, top y=1705.5px. It accounts for 371.314 kB initially in reject (39.3% of partial initial accounted bytes). Native lazy loading fetches it within the browser's loading distance; a lazy attribute is not proof of complete deferral. Responsive candidates merit visual/quality tests at intended densities. No frozen screenshot pixels or alternative rendition provides validated savings or readability.

Home initial image traffic is 482.104 kB; scrolling adds three images at 54.555/62.624/46.215 kB, totaling 163.394 kB (reject). Features initial image traffic is 176.151 kB; scrolling adds 53.310/27.298 kB, totaling 80.608 kB. Sustainability initial images total 130.571 kB; scrolling adds 42.945 kB. These demonstrate working image deferral with later requests; early naturalWidth=0 is not proof of a broken image.

Article first-party media images total 214.128 kB in reject, including logos/authors. All six content screenshots/graphics are initially loaded: 17.907/19.869/32.301/40.587/45.359/45.164 kB, at desktop top positions 1194/2548.7/3777.2/5799.0/6745.5/7742px. The latter five total 183.280 kB and are eager (loading=auto), useful candidates for deferral testing alongside the larger embed work.

Most .png/.jpg URLs negotiate WebP. Two actual article PNGs (schema/API screenshots) are 19.869 and 32.301 kB, with useful code/interface details; don't prescribe lossy conversion without legibility tests. Four sustainability .webp paths expose application/octet-stream and still render. Their MIME correctness can be investigated, but byte savings do not follow from correcting MIME alone. Logo PNG is roughly 7 kB.

First-party main.js is about 11.8 kB received, not the total script category. Home reject separate GTM/gtag/analytics.js transfer is 156.410 + 169.343 + 21.409 = 347.162 kB before cookie choice, compared with 359.725 kB for all accounted Script resources. The unknown Plausible bytes are excluded from that sum. Analytics requirements/gating merit owner review; deletion savings and server behavior are untested. Repeated player logging has no demonstrated redundancy or backend-energy measurement.

Two same-origin WOFF2 files account for around 39.5–40.8 kB ordinarily. Kumbh Sans 400 loads with display=block; 700 with display=auto; 600 is declared but unloaded on six pages. Article loads all three same-origin faces (61.172 kB) plus the iframe's Roboto (40.678 kB). Do not count unloaded 600 as downloaded or infer safe font removal. Constrained/font-blocked readability tests are missing.

## Qualitative findings and evidence pitfalls

- Seven-page live-dark changes match the media query but keep white body background. Every fresh cold-dark initializes rgb(38,38,38). Manual theme activation and explicit stored-choice policy are untested; no energy saving is measured.
- Every JavaScript desktop/narrow state exceeds viewport width by exactly 10px (1290 vs 1280; 370 vs 360). Print and fresh no-JavaScript do not. This supports a common-layout investigation, not an asserted offscreen task failure or a known offending element. Mobile menu activation was not tested.
- All semantic counts are one h1 and one main. Heading arrays truncate before the actual h1 because early navigation headings consume the bounded list: total counts 138/143/126/124/129/121/116. Do not fabricate missing headings or hierarchy defects from that list; full body text is available, and the journey independently verifies Sustainability h1.
- No-JavaScript preserves reading/task text on six pages apart from theme/cookie UI. Contact replaces hello@wagtail.org twice and security@wagtail.org once with protected email placeholders, a direct limitation for its contact task. Other help/community links remain. The ordinary page requests Cloudflare email-decode.min.js; deployment source for the obfuscation setting is unverified.
- Home/features/sustainability have 5/2/1 running one-iteration animations after resize and reduced-motion emulation, while initial desktop lists are empty. Print emulation starts more transitions, up to 61. Captured entries lack animated properties/durations: neither no-motion claims nor looping/reduced-motion-failure claims are supported just by these counts.
- Header/footer navigation and cookie UI hide in print; task text remains. Article images visible in print drop 11 to 8. No PDF pagination, downloaded content or alternative video document was inspected.
- Five-action opt-out/search/policy journey completes with matching URL, unique h1/text and all actions successful. Legacy successSelectorVisible null is not a failure. Twelve Tab steps show visible focus with auto 1px outlines, but do not test reverse traversal, menu activation, traps or every control. No message/newsletter was submitted and no video was played.
- No notification permission calls occur in the snapshots. This is observed scope only. Search intentionally uses noindex and omits canonical/description; content pages have descriptive metadata. Present JSON-LD parses, which is not schema eligibility validation.
- First-party HTML is Brotli with s-maxage=14400, stale-while-revalidate=30, public. Static CSS/JS/fonts are long-lived immutable with ETags; images generally max-age=31536000 with ETags. GTM/gtag use zstd. Do not recommend blanket compression/caching, or fail tiny/private logging/error responses. No warm/offline test proves reuse. Resource Timing cross-origin zeros cannot replace staged CDP byte accounting.
- Initial coverage is 500ms and main target only. Article scripts truncate; CSS contains observed-used ranges only. JS source positions differ from compressed transfer bytes. No defensible safe-removal saving follows from these data.

## Disclosures and source boundaries

carbon.txt is directly available with 200, declares version 0.4 and last_updated=2026-01-07, parses under the common-fields interpretation, but schemaValidated=false. Four declared documents retrieve; 2023/2024 annual reports retain historical periods despite expired valid_until fields. Six documents are captured in discovery, including the newer 2025 footprint report and search listing. Provider declarations for Cloudflare/Heroku/AWS/GitHub are self-declared, not verified green operational scope.

The policy says 5,173 tCO₂e/year for 6,431 sites and 12 tCO₂e/site/year average. The displayed average is inconsistent with 5173/6431 ≈ 0.804 tCO₂e/site/year. Keep that claims issue separate from this origin's bytes. Its ecosystem scope cannot substitute for this website's footprint.

Digital-emissions disclosure describes April 2026 mobile Lighthouse/DebugBear 507 kB first visit, 41.9 kB return, 0.06g and rating A, with world intensity 458.29 g/kWh and Ireland 256.54 g/kWh. It also declares a 30–300 kg/year scenario. Those are published claims with a different period, device/protocol and intensity, not fresh measured results or a directly comparable regression baseline. This audit has no measured traffic, annual footprint or hardware energy.

Wappalyzer heuristically detects Wagtail/Python/Django/Plausible/GTM/GA4/Cloudflare/RSS/PWA/Open Graph in a separate excluded scan. Plausible detection coexists with the 404; PWA detection does not prove offline service with workers blocked. Most versions are empty. /technology has no dedicated evidence-index ID. Candidate source is clean tracked revision 9fa65385f27c15b83c86a4f6e0e3ac18d4784609 with deploymentVerified=false; both lockfiles are metadata only. Declarations are not installed/deployed versions, and selected-file absence is not organization-wide absence of budgets or maintenance.
